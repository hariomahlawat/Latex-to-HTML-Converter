// Generated from Tex_grammar.g4 by ANTLR 4.5
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class Tex_grammarParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, ID=7, DOUBLESLASH=8, LATEX_NEWLINE=9, 
		HFILL=10, BREAK=11, FRAC=12, SQRT=13, SUM=14, INTEGRATION=15, LEFTCURLYB=16, 
		RIGHTCURLYB=17, LEFTSQUAREB=18, RIGHTSQUAREB=19, LEFTPARENTHESES=20, RIGHTPARENTHESES=21, 
		EQUALTO=22, PLUS=23, MUL=24, SUPERSCRIPT=25, SUBSCRIPT=26, AMPERSAND=27, 
		DOUBLEDOLLAR=28, SINGLEDOLLAR=29, SUPEQN=30, SUBEQN=31, DOCCLASS=32, PKGBALANCE=33, 
		PKGGRAPHICX=34, PKGURL=35, PKGAMSMATH=36, PKGMATHTOOLS=37, PKGTABULARX=38, 
		PKGCAPTION=39, PKGSUBCAPTION=40, PKGMULTIROW=41, PKGGRAPHICS=42, BEGINDOC=43, 
		ENDDOC=44, BEGINFIGURE=45, ENDFIGURE=46, INCLUDEGRAPHICS=47, CAPTION=48, 
		BEGIN_CENTER=49, END_CENTER=50, TITLE=51, AUTHOR=52, DATE=53, MAKE_TITLE=54, 
		BEGIN_ABSTRACT=55, END_ABSTRACT=56, SECTION=57, SUBSECTION=58, PARAGRAPH=59, 
		TEXTBF=60, TEXTIT=61, UNDERLINE=62, PAR=63, LABEL=64, REF=65, BEGIN_ENUMERATE=66, 
		ITEM=67, END_ENUMERATE=68, BEGIN_ITEMIZE=69, END_ITEMIZE=70, BEGIN_TABLE=71, 
		END_TABLE=72, BEGIN_TABULAR=73, END_TABULAR=74, TABLE_ALIGNMENT=75, HLINE=76, 
		WORD=77, GREEK_LETTERS=78, RESERVEWORD=79, SPECIALCHAR=80, OPERATOR=81, 
		SKIP2=82, NEWLINE=83, WS=84, INTEGER=85, SINGLECHAR=86, LETTERS=87, TEXT=88;
	public static final int
		RULE_root = 0, RULE_docclass = 1, RULE_preamble = 2, RULE_begindocument = 3, 
		RULE_enddocument = 4, RULE_body_text = 5, RULE_body_parts = 6, RULE_title = 7, 
		RULE_author = 8, RULE_date = 9, RULE_maketitle = 10, RULE_optionalAbstract = 11, 
		RULE_section = 12, RULE_sectionName = 13, RULE_subsection = 14, RULE_subsectionName = 15, 
		RULE_par = 16, RULE_center = 17, RULE_graphicsHW = 18, RULE_graphicsName = 19, 
		RULE_graphics = 20, RULE_figure = 21, RULE_ordered_list = 22, RULE_unordered_list = 23, 
		RULE_item = 24, RULE_listtext = 25, RULE_stat = 26, RULE_expr = 27, RULE_operator = 28, 
		RULE_superscript = 29, RULE_subscript = 30, RULE_frac = 31, RULE_sqrt = 32, 
		RULE_sum = 33, RULE_integralSign = 34, RULE_integral = 35, RULE_integration = 36, 
		RULE_sumsubscript = 37, RULE_sumsuperscript = 38, RULE_mathdata = 39, 
		RULE_fracdata = 40, RULE_fracPart = 41, RULE_inlinemath = 42, RULE_displaymath = 43, 
		RULE_begin_table = 44, RULE_end_table = 45, RULE_begin_tabular = 46, RULE_end_tabular = 47, 
		RULE_table_alignment = 48, RULE_table_row = 49, RULE_doubleslash = 50, 
		RULE_table_column = 51, RULE_table = 52, RULE_latex_newline = 53, RULE_boldtext = 54, 
		RULE_italictext = 55, RULE_underline = 56, RULE_caption = 57, RULE_label = 58, 
		RULE_ref = 59, RULE_text = 60, RULE_fulltext = 61, RULE_word = 62, RULE_letter = 63, 
		RULE_integer = 64, RULE_sentence = 65, RULE_line = 66;
	public static final String[] ruleNames = {
		"root", "docclass", "preamble", "begindocument", "enddocument", "body_text", 
		"body_parts", "title", "author", "date", "maketitle", "optionalAbstract", 
		"section", "sectionName", "subsection", "subsectionName", "par", "center", 
		"graphicsHW", "graphicsName", "graphics", "figure", "ordered_list", "unordered_list", 
		"item", "listtext", "stat", "expr", "operator", "superscript", "subscript", 
		"frac", "sqrt", "sum", "integralSign", "integral", "integration", "sumsubscript", 
		"sumsuperscript", "mathdata", "fracdata", "fracPart", "inlinemath", "displaymath", 
		"begin_table", "end_table", "begin_tabular", "end_tabular", "table_alignment", 
		"table_row", "doubleslash", "table_column", "table", "latex_newline", 
		"boldtext", "italictext", "underline", "caption", "label", "ref", "text", 
		"fulltext", "word", "letter", "integer", "sentence", "line"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "' '", "'/'", "'-'", "'\t'", "'\r'", "'\n'", null, "'\\\\'", "'\\newline'", 
		"'\\hfill'", "'\\break'", "'\\frac'", "'\\sqrt'", "'\\sum'", "'\\int'", 
		"'{'", "'}'", "'['", "']'", "'('", "')'", "'='", "'+'", "'*'", "'^'", 
		"'_'", "'&'", "'$$'", "'$'", null, null, null, null, null, null, null, 
		null, null, null, null, null, null, null, null, "'\\begin{figure}'", "'\\end{figure}'", 
		"'\\includegraphics'", "'\\caption'", "'\\begin{center}'", "'\\end{center}'", 
		null, null, null, "'\\maketitle'", "'\\begin{abstract}'", "'\\end{abstract}'", 
		"'\\section'", "'\\subsection'", "'\\paragraph'", "'\\textbf'", "'\\textit'", 
		"'\\underline'", "'\\par'", "'\\label'", "'\\ref'", null, "'\\item'", 
		null, null, null, "'\\begin{table}'", "'\\end{table}'", "'\\begin{tabular}'", 
		"'\\end{tabular}'", null, "'\\hline'", null, null, null, null, null, "'\r\n'", 
		null, null, null, "'.'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, "ID", "DOUBLESLASH", "LATEX_NEWLINE", 
		"HFILL", "BREAK", "FRAC", "SQRT", "SUM", "INTEGRATION", "LEFTCURLYB", 
		"RIGHTCURLYB", "LEFTSQUAREB", "RIGHTSQUAREB", "LEFTPARENTHESES", "RIGHTPARENTHESES", 
		"EQUALTO", "PLUS", "MUL", "SUPERSCRIPT", "SUBSCRIPT", "AMPERSAND", "DOUBLEDOLLAR", 
		"SINGLEDOLLAR", "SUPEQN", "SUBEQN", "DOCCLASS", "PKGBALANCE", "PKGGRAPHICX", 
		"PKGURL", "PKGAMSMATH", "PKGMATHTOOLS", "PKGTABULARX", "PKGCAPTION", "PKGSUBCAPTION", 
		"PKGMULTIROW", "PKGGRAPHICS", "BEGINDOC", "ENDDOC", "BEGINFIGURE", "ENDFIGURE", 
		"INCLUDEGRAPHICS", "CAPTION", "BEGIN_CENTER", "END_CENTER", "TITLE", "AUTHOR", 
		"DATE", "MAKE_TITLE", "BEGIN_ABSTRACT", "END_ABSTRACT", "SECTION", "SUBSECTION", 
		"PARAGRAPH", "TEXTBF", "TEXTIT", "UNDERLINE", "PAR", "LABEL", "REF", "BEGIN_ENUMERATE", 
		"ITEM", "END_ENUMERATE", "BEGIN_ITEMIZE", "END_ITEMIZE", "BEGIN_TABLE", 
		"END_TABLE", "BEGIN_TABULAR", "END_TABULAR", "TABLE_ALIGNMENT", "HLINE", 
		"WORD", "GREEK_LETTERS", "RESERVEWORD", "SPECIALCHAR", "OPERATOR", "SKIP2", 
		"NEWLINE", "WS", "INTEGER", "SINGLECHAR", "LETTERS", "TEXT"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Tex_grammar.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public Tex_grammarParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class RootContext extends ParserRuleContext {
		public DocclassContext docclass() {
			return getRuleContext(DocclassContext.class,0);
		}
		public BegindocumentContext begindocument() {
			return getRuleContext(BegindocumentContext.class,0);
		}
		public Body_textContext body_text() {
			return getRuleContext(Body_textContext.class,0);
		}
		public EnddocumentContext enddocument() {
			return getRuleContext(EnddocumentContext.class,0);
		}
		public TerminalNode EOF() { return getToken(Tex_grammarParser.EOF, 0); }
		public List<PreambleContext> preamble() {
			return getRuleContexts(PreambleContext.class);
		}
		public PreambleContext preamble(int i) {
			return getRuleContext(PreambleContext.class,i);
		}
		public List<TitleContext> title() {
			return getRuleContexts(TitleContext.class);
		}
		public TitleContext title(int i) {
			return getRuleContext(TitleContext.class,i);
		}
		public List<AuthorContext> author() {
			return getRuleContexts(AuthorContext.class);
		}
		public AuthorContext author(int i) {
			return getRuleContext(AuthorContext.class,i);
		}
		public List<DateContext> date() {
			return getRuleContexts(DateContext.class);
		}
		public DateContext date(int i) {
			return getRuleContext(DateContext.class,i);
		}
		public RootContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_root; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterRoot(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitRoot(this);
		}
	}

	public final RootContext root() throws RecognitionException {
		RootContext _localctx = new RootContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_root);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(134);
			docclass();
			setState(138);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << PKGBALANCE) | (1L << PKGGRAPHICX) | (1L << PKGURL) | (1L << PKGAMSMATH) | (1L << PKGMATHTOOLS) | (1L << PKGTABULARX) | (1L << PKGCAPTION) | (1L << PKGSUBCAPTION) | (1L << PKGMULTIROW) | (1L << PKGGRAPHICS))) != 0)) {
				{
				{
				setState(135);
				preamble();
				}
				}
				setState(140);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(141);
			begindocument();
			setState(145);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==TITLE) {
				{
				{
				setState(142);
				title();
				}
				}
				setState(147);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(151);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AUTHOR) {
				{
				{
				setState(148);
				author();
				}
				}
				setState(153);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(157);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DATE) {
				{
				{
				setState(154);
				date();
				}
				}
				setState(159);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(160);
			body_text(0);
			setState(161);
			enddocument();
			setState(162);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DocclassContext extends ParserRuleContext {
		public TerminalNode DOCCLASS() { return getToken(Tex_grammarParser.DOCCLASS, 0); }
		public DocclassContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_docclass; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterDocclass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitDocclass(this);
		}
	}

	public final DocclassContext docclass() throws RecognitionException {
		DocclassContext _localctx = new DocclassContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_docclass);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(164);
			match(DOCCLASS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PreambleContext extends ParserRuleContext {
		public TerminalNode PKGAMSMATH() { return getToken(Tex_grammarParser.PKGAMSMATH, 0); }
		public TerminalNode PKGBALANCE() { return getToken(Tex_grammarParser.PKGBALANCE, 0); }
		public TerminalNode PKGCAPTION() { return getToken(Tex_grammarParser.PKGCAPTION, 0); }
		public TerminalNode PKGGRAPHICS() { return getToken(Tex_grammarParser.PKGGRAPHICS, 0); }
		public TerminalNode PKGGRAPHICX() { return getToken(Tex_grammarParser.PKGGRAPHICX, 0); }
		public TerminalNode PKGMATHTOOLS() { return getToken(Tex_grammarParser.PKGMATHTOOLS, 0); }
		public TerminalNode PKGMULTIROW() { return getToken(Tex_grammarParser.PKGMULTIROW, 0); }
		public TerminalNode PKGSUBCAPTION() { return getToken(Tex_grammarParser.PKGSUBCAPTION, 0); }
		public TerminalNode PKGTABULARX() { return getToken(Tex_grammarParser.PKGTABULARX, 0); }
		public TerminalNode PKGURL() { return getToken(Tex_grammarParser.PKGURL, 0); }
		public PreambleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_preamble; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterPreamble(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitPreamble(this);
		}
	}

	public final PreambleContext preamble() throws RecognitionException {
		PreambleContext _localctx = new PreambleContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_preamble);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(166);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << PKGBALANCE) | (1L << PKGGRAPHICX) | (1L << PKGURL) | (1L << PKGAMSMATH) | (1L << PKGMATHTOOLS) | (1L << PKGTABULARX) | (1L << PKGCAPTION) | (1L << PKGSUBCAPTION) | (1L << PKGMULTIROW) | (1L << PKGGRAPHICS))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BegindocumentContext extends ParserRuleContext {
		public TerminalNode BEGINDOC() { return getToken(Tex_grammarParser.BEGINDOC, 0); }
		public BegindocumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_begindocument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterBegindocument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitBegindocument(this);
		}
	}

	public final BegindocumentContext begindocument() throws RecognitionException {
		BegindocumentContext _localctx = new BegindocumentContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_begindocument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			match(BEGINDOC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EnddocumentContext extends ParserRuleContext {
		public TerminalNode ENDDOC() { return getToken(Tex_grammarParser.ENDDOC, 0); }
		public EnddocumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_enddocument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterEnddocument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitEnddocument(this);
		}
	}

	public final EnddocumentContext enddocument() throws RecognitionException {
		EnddocumentContext _localctx = new EnddocumentContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_enddocument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(170);
			match(ENDDOC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Body_textContext extends ParserRuleContext {
		public Body_partsContext body_parts() {
			return getRuleContext(Body_partsContext.class,0);
		}
		public Body_textContext body_text() {
			return getRuleContext(Body_textContext.class,0);
		}
		public Body_textContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_body_text; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterBody_text(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitBody_text(this);
		}
	}

	public final Body_textContext body_text() throws RecognitionException {
		return body_text(0);
	}

	private Body_textContext body_text(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Body_textContext _localctx = new Body_textContext(_ctx, _parentState);
		Body_textContext _prevctx = _localctx;
		int _startState = 10;
		enterRecursionRule(_localctx, 10, RULE_body_text, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(173);
			body_parts();
			}
			_ctx.stop = _input.LT(-1);
			setState(179);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Body_textContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_body_text);
					setState(175);
					if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
					setState(176);
					body_parts();
					}
					} 
				}
				setState(181);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class Body_partsContext extends ParserRuleContext {
		public OptionalAbstractContext optionalAbstract() {
			return getRuleContext(OptionalAbstractContext.class,0);
		}
		public SectionContext section() {
			return getRuleContext(SectionContext.class,0);
		}
		public SubsectionContext subsection() {
			return getRuleContext(SubsectionContext.class,0);
		}
		public LabelContext label() {
			return getRuleContext(LabelContext.class,0);
		}
		public RefContext ref() {
			return getRuleContext(RefContext.class,0);
		}
		public Ordered_listContext ordered_list() {
			return getRuleContext(Ordered_listContext.class,0);
		}
		public Unordered_listContext unordered_list() {
			return getRuleContext(Unordered_listContext.class,0);
		}
		public MaketitleContext maketitle() {
			return getRuleContext(MaketitleContext.class,0);
		}
		public FigureContext figure() {
			return getRuleContext(FigureContext.class,0);
		}
		public FulltextContext fulltext() {
			return getRuleContext(FulltextContext.class,0);
		}
		public Body_partsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_body_parts; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterBody_parts(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitBody_parts(this);
		}
	}

	public final Body_partsContext body_parts() throws RecognitionException {
		Body_partsContext _localctx = new Body_partsContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_body_parts);
		try {
			setState(192);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(182);
				optionalAbstract();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(183);
				section();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(184);
				subsection();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(185);
				label();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(186);
				ref();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(187);
				ordered_list();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(188);
				unordered_list();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(189);
				maketitle();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(190);
				figure();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(191);
				fulltext(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TitleContext extends ParserRuleContext {
		public TerminalNode TITLE() { return getToken(Tex_grammarParser.TITLE, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public TitleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_title; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterTitle(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitTitle(this);
		}
	}

	public final TitleContext title() throws RecognitionException {
		TitleContext _localctx = new TitleContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_title);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(194);
			match(TITLE);
			setState(198);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(195);
					match(NEWLINE);
					}
					} 
				}
				setState(200);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AuthorContext extends ParserRuleContext {
		public TerminalNode AUTHOR() { return getToken(Tex_grammarParser.AUTHOR, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public AuthorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_author; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterAuthor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitAuthor(this);
		}
	}

	public final AuthorContext author() throws RecognitionException {
		AuthorContext _localctx = new AuthorContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_author);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(201);
			match(AUTHOR);
			setState(205);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(202);
					match(NEWLINE);
					}
					} 
				}
				setState(207);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DateContext extends ParserRuleContext {
		public TerminalNode DATE() { return getToken(Tex_grammarParser.DATE, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public DateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_date; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterDate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitDate(this);
		}
	}

	public final DateContext date() throws RecognitionException {
		DateContext _localctx = new DateContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_date);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(208);
			match(DATE);
			setState(212);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(209);
					match(NEWLINE);
					}
					} 
				}
				setState(214);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MaketitleContext extends ParserRuleContext {
		public TerminalNode MAKE_TITLE() { return getToken(Tex_grammarParser.MAKE_TITLE, 0); }
		public MaketitleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_maketitle; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterMaketitle(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitMaketitle(this);
		}
	}

	public final MaketitleContext maketitle() throws RecognitionException {
		MaketitleContext _localctx = new MaketitleContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_maketitle);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(215);
			match(MAKE_TITLE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OptionalAbstractContext extends ParserRuleContext {
		public TerminalNode BEGIN_ABSTRACT() { return getToken(Tex_grammarParser.BEGIN_ABSTRACT, 0); }
		public FulltextContext fulltext() {
			return getRuleContext(FulltextContext.class,0);
		}
		public TerminalNode END_ABSTRACT() { return getToken(Tex_grammarParser.END_ABSTRACT, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public OptionalAbstractContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_optionalAbstract; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterOptionalAbstract(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitOptionalAbstract(this);
		}
	}

	public final OptionalAbstractContext optionalAbstract() throws RecognitionException {
		OptionalAbstractContext _localctx = new OptionalAbstractContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_optionalAbstract);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(217);
			match(BEGIN_ABSTRACT);
			setState(221);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(218);
					match(NEWLINE);
					}
					} 
				}
				setState(223);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			}
			setState(224);
			fulltext(0);
			setState(228);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(225);
				match(NEWLINE);
				}
				}
				setState(230);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(231);
			match(END_ABSTRACT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SectionContext extends ParserRuleContext {
		public SectionNameContext sectionName() {
			return getRuleContext(SectionNameContext.class,0);
		}
		public List<FulltextContext> fulltext() {
			return getRuleContexts(FulltextContext.class);
		}
		public FulltextContext fulltext(int i) {
			return getRuleContext(FulltextContext.class,i);
		}
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public SectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_section; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSection(this);
		}
	}

	public final SectionContext section() throws RecognitionException {
		SectionContext _localctx = new SectionContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_section);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(233);
			sectionName();
			setState(237);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(234);
					fulltext(0);
					}
					} 
				}
				setState(239);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			}
			setState(243);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(240);
					text();
					}
					} 
				}
				setState(245);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			}
			setState(249);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(246);
					fulltext(0);
					}
					} 
				}
				setState(251);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SectionNameContext extends ParserRuleContext {
		public TerminalNode SECTION() { return getToken(Tex_grammarParser.SECTION, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public SectionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sectionName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSectionName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSectionName(this);
		}
	}

	public final SectionNameContext sectionName() throws RecognitionException {
		SectionNameContext _localctx = new SectionNameContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_sectionName);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(252);
			match(SECTION);
			setState(256);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(253);
				match(T__0);
				}
				}
				setState(258);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(259);
			match(LEFTCURLYB);
			setState(260);
			text();
			setState(261);
			match(RIGHTCURLYB);
			setState(265);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(262);
					match(NEWLINE);
					}
					} 
				}
				setState(267);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SubsectionContext extends ParserRuleContext {
		public SubsectionNameContext subsectionName() {
			return getRuleContext(SubsectionNameContext.class,0);
		}
		public List<FulltextContext> fulltext() {
			return getRuleContexts(FulltextContext.class);
		}
		public FulltextContext fulltext(int i) {
			return getRuleContext(FulltextContext.class,i);
		}
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public SubsectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subsection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSubsection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSubsection(this);
		}
	}

	public final SubsectionContext subsection() throws RecognitionException {
		SubsectionContext _localctx = new SubsectionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_subsection);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(268);
			subsectionName();
			setState(269);
			fulltext(0);
			setState(273);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,16,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(270);
					text();
					}
					} 
				}
				setState(275);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,16,_ctx);
			}
			setState(279);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(276);
					fulltext(0);
					}
					} 
				}
				setState(281);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SubsectionNameContext extends ParserRuleContext {
		public TerminalNode SUBSECTION() { return getToken(Tex_grammarParser.SUBSECTION, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public SubsectionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subsectionName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSubsectionName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSubsectionName(this);
		}
	}

	public final SubsectionNameContext subsectionName() throws RecognitionException {
		SubsectionNameContext _localctx = new SubsectionNameContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_subsectionName);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(282);
			match(SUBSECTION);
			setState(286);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(283);
				match(T__0);
				}
				}
				setState(288);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(289);
			match(LEFTCURLYB);
			setState(290);
			text();
			setState(291);
			match(RIGHTCURLYB);
			setState(295);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(292);
					match(NEWLINE);
					}
					} 
				}
				setState(297);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParContext extends ParserRuleContext {
		public TerminalNode PAR() { return getToken(Tex_grammarParser.PAR, 0); }
		public ParContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_par; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterPar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitPar(this);
		}
	}

	public final ParContext par() throws RecognitionException {
		ParContext _localctx = new ParContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_par);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(298);
			match(PAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CenterContext extends ParserRuleContext {
		public TerminalNode BEGIN_CENTER() { return getToken(Tex_grammarParser.BEGIN_CENTER, 0); }
		public TerminalNode END_CENTER() { return getToken(Tex_grammarParser.END_CENTER, 0); }
		public List<FulltextContext> fulltext() {
			return getRuleContexts(FulltextContext.class);
		}
		public FulltextContext fulltext(int i) {
			return getRuleContext(FulltextContext.class,i);
		}
		public CenterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_center; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterCenter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitCenter(this);
		}
	}

	public final CenterContext center() throws RecognitionException {
		CenterContext _localctx = new CenterContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_center);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(300);
			match(BEGIN_CENTER);
			setState(304);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__2) | (1L << ID) | (1L << DOUBLESLASH) | (1L << LATEX_NEWLINE) | (1L << HFILL) | (1L << FRAC) | (1L << SQRT) | (1L << SUM) | (1L << INTEGRATION) | (1L << LEFTPARENTHESES) | (1L << RIGHTPARENTHESES) | (1L << EQUALTO) | (1L << PLUS) | (1L << MUL) | (1L << DOUBLEDOLLAR) | (1L << SINGLEDOLLAR) | (1L << CAPTION) | (1L << BEGIN_CENTER) | (1L << TEXTBF) | (1L << TEXTIT) | (1L << UNDERLINE) | (1L << PAR))) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & ((1L << (LABEL - 64)) | (1L << (REF - 64)) | (1L << (BEGIN_TABLE - 64)) | (1L << (BEGIN_TABULAR - 64)) | (1L << (WORD - 64)) | (1L << (NEWLINE - 64)) | (1L << (INTEGER - 64)) | (1L << (SINGLECHAR - 64)) | (1L << (LETTERS - 64)) | (1L << (TEXT - 64)))) != 0)) {
				{
				{
				setState(301);
				fulltext(0);
				}
				}
				setState(306);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(307);
			match(END_CENTER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GraphicsHWContext extends ParserRuleContext {
		public TerminalNode TEXT() { return getToken(Tex_grammarParser.TEXT, 0); }
		public GraphicsHWContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_graphicsHW; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterGraphicsHW(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitGraphicsHW(this);
		}
	}

	public final GraphicsHWContext graphicsHW() throws RecognitionException {
		GraphicsHWContext _localctx = new GraphicsHWContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_graphicsHW);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(309);
			match(LEFTSQUAREB);
			setState(310);
			match(TEXT);
			setState(311);
			match(RIGHTSQUAREB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GraphicsNameContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(Tex_grammarParser.WORD, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public GraphicsNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_graphicsName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterGraphicsName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitGraphicsName(this);
		}
	}

	public final GraphicsNameContext graphicsName() throws RecognitionException {
		GraphicsNameContext _localctx = new GraphicsNameContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_graphicsName);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(313);
			match(LEFTCURLYB);
			setState(314);
			match(WORD);
			setState(315);
			match(RIGHTCURLYB);
			setState(319);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(316);
				match(NEWLINE);
				}
				}
				setState(321);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GraphicsContext extends ParserRuleContext {
		public TerminalNode INCLUDEGRAPHICS() { return getToken(Tex_grammarParser.INCLUDEGRAPHICS, 0); }
		public GraphicsNameContext graphicsName() {
			return getRuleContext(GraphicsNameContext.class,0);
		}
		public GraphicsHWContext graphicsHW() {
			return getRuleContext(GraphicsHWContext.class,0);
		}
		public GraphicsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_graphics; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterGraphics(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitGraphics(this);
		}
	}

	public final GraphicsContext graphics() throws RecognitionException {
		GraphicsContext _localctx = new GraphicsContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_graphics);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(322);
			match(INCLUDEGRAPHICS);
			setState(324);
			_la = _input.LA(1);
			if (_la==LEFTSQUAREB) {
				{
				setState(323);
				graphicsHW();
				}
			}

			setState(326);
			graphicsName();
			setState(330);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0 || _la==SKIP2) {
				{
				{
				setState(327);
				_la = _input.LA(1);
				if ( !(_la==T__0 || _la==SKIP2) ) {
				_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
				}
				setState(332);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FigureContext extends ParserRuleContext {
		public TerminalNode BEGINFIGURE() { return getToken(Tex_grammarParser.BEGINFIGURE, 0); }
		public GraphicsContext graphics() {
			return getRuleContext(GraphicsContext.class,0);
		}
		public TerminalNode ENDFIGURE() { return getToken(Tex_grammarParser.ENDFIGURE, 0); }
		public List<LabelContext> label() {
			return getRuleContexts(LabelContext.class);
		}
		public LabelContext label(int i) {
			return getRuleContext(LabelContext.class,i);
		}
		public CaptionContext caption() {
			return getRuleContext(CaptionContext.class,0);
		}
		public FigureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figure; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterFigure(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitFigure(this);
		}
	}

	public final FigureContext figure() throws RecognitionException {
		FigureContext _localctx = new FigureContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_figure);
		int _la;
		try {
			setState(353);
			switch ( getInterpreter().adaptivePredict(_input,28,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(333);
				match(BEGINFIGURE);
				setState(334);
				graphics();
				setState(336);
				switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
				case 1:
					{
					setState(335);
					label();
					}
					break;
				}
				setState(339);
				_la = _input.LA(1);
				if (_la==CAPTION) {
					{
					setState(338);
					caption();
					}
				}

				setState(342);
				_la = _input.LA(1);
				if (_la==LABEL) {
					{
					setState(341);
					label();
					}
				}

				setState(344);
				match(ENDFIGURE);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(346);
				match(BEGINFIGURE);
				setState(348);
				_la = _input.LA(1);
				if (_la==CAPTION) {
					{
					setState(347);
					caption();
					}
				}

				setState(350);
				graphics();
				setState(351);
				match(ENDFIGURE);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ordered_listContext extends ParserRuleContext {
		public TerminalNode BEGIN_ENUMERATE() { return getToken(Tex_grammarParser.BEGIN_ENUMERATE, 0); }
		public TerminalNode END_ENUMERATE() { return getToken(Tex_grammarParser.END_ENUMERATE, 0); }
		public List<ItemContext> item() {
			return getRuleContexts(ItemContext.class);
		}
		public ItemContext item(int i) {
			return getRuleContext(ItemContext.class,i);
		}
		public Ordered_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ordered_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterOrdered_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitOrdered_list(this);
		}
	}

	public final Ordered_listContext ordered_list() throws RecognitionException {
		Ordered_listContext _localctx = new Ordered_listContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_ordered_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(355);
			match(BEGIN_ENUMERATE);
			setState(357); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(356);
				item();
				}
				}
				setState(359); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((((_la - 66)) & ~0x3f) == 0 && ((1L << (_la - 66)) & ((1L << (BEGIN_ENUMERATE - 66)) | (1L << (ITEM - 66)) | (1L << (BEGIN_ITEMIZE - 66)))) != 0) );
			setState(361);
			match(END_ENUMERATE);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Unordered_listContext extends ParserRuleContext {
		public TerminalNode BEGIN_ITEMIZE() { return getToken(Tex_grammarParser.BEGIN_ITEMIZE, 0); }
		public TerminalNode END_ITEMIZE() { return getToken(Tex_grammarParser.END_ITEMIZE, 0); }
		public List<ItemContext> item() {
			return getRuleContexts(ItemContext.class);
		}
		public ItemContext item(int i) {
			return getRuleContext(ItemContext.class,i);
		}
		public Unordered_listContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unordered_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterUnordered_list(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitUnordered_list(this);
		}
	}

	public final Unordered_listContext unordered_list() throws RecognitionException {
		Unordered_listContext _localctx = new Unordered_listContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_unordered_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(363);
			match(BEGIN_ITEMIZE);
			setState(365); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(364);
				item();
				}
				}
				setState(367); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((((_la - 66)) & ~0x3f) == 0 && ((1L << (_la - 66)) & ((1L << (BEGIN_ENUMERATE - 66)) | (1L << (ITEM - 66)) | (1L << (BEGIN_ITEMIZE - 66)))) != 0) );
			setState(369);
			match(END_ITEMIZE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ItemContext extends ParserRuleContext {
		public List<TerminalNode> ITEM() { return getTokens(Tex_grammarParser.ITEM); }
		public TerminalNode ITEM(int i) {
			return getToken(Tex_grammarParser.ITEM, i);
		}
		public List<ListtextContext> listtext() {
			return getRuleContexts(ListtextContext.class);
		}
		public ListtextContext listtext(int i) {
			return getRuleContext(ListtextContext.class,i);
		}
		public Ordered_listContext ordered_list() {
			return getRuleContext(Ordered_listContext.class,0);
		}
		public ItemContext item() {
			return getRuleContext(ItemContext.class,0);
		}
		public Unordered_listContext unordered_list() {
			return getRuleContext(Unordered_listContext.class,0);
		}
		public ItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitItem(this);
		}
	}

	public final ItemContext item() throws RecognitionException {
		ItemContext _localctx = new ItemContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_item);
		try {
			int _alt;
			setState(383);
			switch (_input.LA(1)) {
			case ITEM:
				enterOuterAlt(_localctx, 1);
				{
				setState(373); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(371);
						match(ITEM);
						setState(372);
						listtext();
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(375); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,31,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				}
				break;
			case BEGIN_ENUMERATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(377);
				ordered_list();
				setState(378);
				item();
				}
				break;
			case BEGIN_ITEMIZE:
				enterOuterAlt(_localctx, 3);
				{
				setState(380);
				unordered_list();
				setState(381);
				item();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ListtextContext extends ParserRuleContext {
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public ListtextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_listtext; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterListtext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitListtext(this);
		}
	}

	public final ListtextContext listtext() throws RecognitionException {
		ListtextContext _localctx = new ListtextContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_listtext);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(388);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(385);
					match(T__0);
					}
					} 
				}
				setState(390);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
			}
			setState(394);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,34,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(391);
					text();
					}
					} 
				}
				setState(396);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,34,_ctx);
			}
			setState(400);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(397);
				match(NEWLINE);
				}
				}
				setState(402);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode NEWLINE() { return getToken(Tex_grammarParser.NEWLINE, 0); }
		public TerminalNode ID() { return getToken(Tex_grammarParser.ID, 0); }
		public StatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stat; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterStat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitStat(this);
		}
	}

	public final StatContext stat() throws RecognitionException {
		StatContext _localctx = new StatContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_stat);
		try {
			setState(414);
			switch ( getInterpreter().adaptivePredict(_input,38,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(403);
				expr(0);
				setState(405);
				switch ( getInterpreter().adaptivePredict(_input,36,_ctx) ) {
				case 1:
					{
					setState(404);
					match(NEWLINE);
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(407);
				match(ID);
				setState(408);
				match(EQUALTO);
				setState(409);
				expr(0);
				setState(411);
				switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
				case 1:
					{
					setState(410);
					match(NEWLINE);
					}
					break;
				}
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(413);
				match(NEWLINE);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public TerminalNode INTEGER() { return getToken(Tex_grammarParser.INTEGER, 0); }
		public TerminalNode ID() { return getToken(Tex_grammarParser.ID, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitExpr(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 54;
		enterRecursionRule(_localctx, 54, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(423);
			switch (_input.LA(1)) {
			case INTEGER:
				{
				setState(417);
				match(INTEGER);
				}
				break;
			case ID:
				{
				setState(418);
				match(ID);
				}
				break;
			case LEFTPARENTHESES:
				{
				setState(419);
				match(LEFTPARENTHESES);
				setState(420);
				expr(0);
				setState(421);
				match(RIGHTPARENTHESES);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(430);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new ExprContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_expr);
					setState(425);
					if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
					setState(426);
					_la = _input.LA(1);
					if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__1) | (1L << T__2) | (1L << PLUS) | (1L << MUL))) != 0)) ) {
					_errHandler.recoverInline(this);
					} else {
						consume();
					}
					setState(427);
					expr(5);
					}
					} 
				}
				setState(432);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class OperatorContext extends ParserRuleContext {
		public TerminalNode OPERATOR() { return getToken(Tex_grammarParser.OPERATOR, 0); }
		public OperatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitOperator(this);
		}
	}

	public final OperatorContext operator() throws RecognitionException {
		OperatorContext _localctx = new OperatorContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_operator);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(433);
			match(OPERATOR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SuperscriptContext extends ParserRuleContext {
		public TerminalNode SUPEQN() { return getToken(Tex_grammarParser.SUPEQN, 0); }
		public SuperscriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_superscript; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSuperscript(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSuperscript(this);
		}
	}

	public final SuperscriptContext superscript() throws RecognitionException {
		SuperscriptContext _localctx = new SuperscriptContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_superscript);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(435);
			match(SUPEQN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SubscriptContext extends ParserRuleContext {
		public TerminalNode SUBEQN() { return getToken(Tex_grammarParser.SUBEQN, 0); }
		public SubscriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subscript; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSubscript(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSubscript(this);
		}
	}

	public final SubscriptContext subscript() throws RecognitionException {
		SubscriptContext _localctx = new SubscriptContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_subscript);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(437);
			match(SUBEQN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FracContext extends ParserRuleContext {
		public TerminalNode FRAC() { return getToken(Tex_grammarParser.FRAC, 0); }
		public FracdataContext fracdata() {
			return getRuleContext(FracdataContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public FracContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frac; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterFrac(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitFrac(this);
		}
	}

	public final FracContext frac() throws RecognitionException {
		FracContext _localctx = new FracContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_frac);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(439);
			match(FRAC);
			setState(440);
			fracdata();
			setState(444);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,41,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(441);
					match(NEWLINE);
					}
					} 
				}
				setState(446);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,41,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SqrtContext extends ParserRuleContext {
		public TerminalNode SQRT() { return getToken(Tex_grammarParser.SQRT, 0); }
		public MathdataContext mathdata() {
			return getRuleContext(MathdataContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public FracContext frac() {
			return getRuleContext(FracContext.class,0);
		}
		public IntegralContext integral() {
			return getRuleContext(IntegralContext.class,0);
		}
		public SqrtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sqrt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSqrt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSqrt(this);
		}
	}

	public final SqrtContext sqrt() throws RecognitionException {
		SqrtContext _localctx = new SqrtContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_sqrt);
		try {
			int _alt;
			setState(459);
			switch ( getInterpreter().adaptivePredict(_input,43,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(447);
				match(SQRT);
				setState(448);
				mathdata();
				setState(452);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,42,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(449);
						match(NEWLINE);
						}
						} 
					}
					setState(454);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,42,_ctx);
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(455);
				match(SQRT);
				setState(456);
				frac();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(457);
				match(SQRT);
				setState(458);
				integral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SumContext extends ParserRuleContext {
		public TerminalNode SUM() { return getToken(Tex_grammarParser.SUM, 0); }
		public TerminalNode SUBSCRIPT() { return getToken(Tex_grammarParser.SUBSCRIPT, 0); }
		public SumsubscriptContext sumsubscript() {
			return getRuleContext(SumsubscriptContext.class,0);
		}
		public TerminalNode SUPERSCRIPT() { return getToken(Tex_grammarParser.SUPERSCRIPT, 0); }
		public SumsuperscriptContext sumsuperscript() {
			return getRuleContext(SumsuperscriptContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public SumContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sum; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSum(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSum(this);
		}
	}

	public final SumContext sum() throws RecognitionException {
		SumContext _localctx = new SumContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_sum);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(461);
			match(SUM);
			setState(462);
			match(SUBSCRIPT);
			setState(463);
			sumsubscript();
			setState(464);
			match(SUPERSCRIPT);
			setState(465);
			sumsuperscript();
			setState(469);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,44,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(466);
					match(NEWLINE);
					}
					} 
				}
				setState(471);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,44,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntegralSignContext extends ParserRuleContext {
		public TerminalNode INTEGRATION() { return getToken(Tex_grammarParser.INTEGRATION, 0); }
		public IntegralSignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integralSign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterIntegralSign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitIntegralSign(this);
		}
	}

	public final IntegralSignContext integralSign() throws RecognitionException {
		IntegralSignContext _localctx = new IntegralSignContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_integralSign);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(472);
			match(INTEGRATION);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntegralContext extends ParserRuleContext {
		public IntegralSignContext integralSign() {
			return getRuleContext(IntegralSignContext.class,0);
		}
		public TerminalNode SUBSCRIPT() { return getToken(Tex_grammarParser.SUBSCRIPT, 0); }
		public SumsubscriptContext sumsubscript() {
			return getRuleContext(SumsubscriptContext.class,0);
		}
		public TerminalNode SUPERSCRIPT() { return getToken(Tex_grammarParser.SUPERSCRIPT, 0); }
		public SumsuperscriptContext sumsuperscript() {
			return getRuleContext(SumsuperscriptContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public IntegralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterIntegral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitIntegral(this);
		}
	}

	public final IntegralContext integral() throws RecognitionException {
		IntegralContext _localctx = new IntegralContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_integral);
		try {
			int _alt;
			setState(486);
			switch ( getInterpreter().adaptivePredict(_input,46,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(474);
				integralSign();
				setState(475);
				match(SUBSCRIPT);
				setState(476);
				sumsubscript();
				setState(477);
				match(SUPERSCRIPT);
				setState(478);
				sumsuperscript();
				setState(482);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,45,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(479);
						match(NEWLINE);
						}
						} 
					}
					setState(484);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,45,_ctx);
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(485);
				integralSign();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntegrationContext extends ParserRuleContext {
		public IntegralContext integral() {
			return getRuleContext(IntegralContext.class,0);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public IntegrationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterIntegration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitIntegration(this);
		}
	}

	public final IntegrationContext integration() throws RecognitionException {
		IntegrationContext _localctx = new IntegrationContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_integration);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(488);
			integral();
			setState(492);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,47,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(489);
					expr(0);
					}
					} 
				}
				setState(494);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,47,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SumsubscriptContext extends ParserRuleContext {
		public TerminalNode LEFTCURLYB() { return getToken(Tex_grammarParser.LEFTCURLYB, 0); }
		public TerminalNode RIGHTCURLYB() { return getToken(Tex_grammarParser.RIGHTCURLYB, 0); }
		public List<TerminalNode> EQUALTO() { return getTokens(Tex_grammarParser.EQUALTO); }
		public TerminalNode EQUALTO(int i) {
			return getToken(Tex_grammarParser.EQUALTO, i);
		}
		public List<TerminalNode> ID() { return getTokens(Tex_grammarParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(Tex_grammarParser.ID, i);
		}
		public List<TerminalNode> WORD() { return getTokens(Tex_grammarParser.WORD); }
		public TerminalNode WORD(int i) {
			return getToken(Tex_grammarParser.WORD, i);
		}
		public List<TerminalNode> LETTERS() { return getTokens(Tex_grammarParser.LETTERS); }
		public TerminalNode LETTERS(int i) {
			return getToken(Tex_grammarParser.LETTERS, i);
		}
		public List<TerminalNode> SINGLECHAR() { return getTokens(Tex_grammarParser.SINGLECHAR); }
		public TerminalNode SINGLECHAR(int i) {
			return getToken(Tex_grammarParser.SINGLECHAR, i);
		}
		public SumsubscriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sumsubscript; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSumsubscript(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSumsubscript(this);
		}
	}

	public final SumsubscriptContext sumsubscript() throws RecognitionException {
		SumsubscriptContext _localctx = new SumsubscriptContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_sumsubscript);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(495);
			match(LEFTCURLYB);
			setState(496);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << ID) | (1L << EQUALTO))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			setState(498);
			switch ( getInterpreter().adaptivePredict(_input,48,_ctx) ) {
			case 1:
				{
				setState(497);
				match(EQUALTO);
				}
				break;
			}
			setState(501);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << ID) | (1L << EQUALTO))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)))) != 0)) {
				{
				setState(500);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << ID) | (1L << EQUALTO))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)))) != 0)) ) {
				_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
			}

			setState(503);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SumsuperscriptContext extends ParserRuleContext {
		public TerminalNode LEFTCURLYB() { return getToken(Tex_grammarParser.LEFTCURLYB, 0); }
		public TerminalNode RIGHTCURLYB() { return getToken(Tex_grammarParser.RIGHTCURLYB, 0); }
		public List<TerminalNode> EQUALTO() { return getTokens(Tex_grammarParser.EQUALTO); }
		public TerminalNode EQUALTO(int i) {
			return getToken(Tex_grammarParser.EQUALTO, i);
		}
		public List<TerminalNode> ID() { return getTokens(Tex_grammarParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(Tex_grammarParser.ID, i);
		}
		public List<TerminalNode> WORD() { return getTokens(Tex_grammarParser.WORD); }
		public TerminalNode WORD(int i) {
			return getToken(Tex_grammarParser.WORD, i);
		}
		public List<TerminalNode> LETTERS() { return getTokens(Tex_grammarParser.LETTERS); }
		public TerminalNode LETTERS(int i) {
			return getToken(Tex_grammarParser.LETTERS, i);
		}
		public List<TerminalNode> SINGLECHAR() { return getTokens(Tex_grammarParser.SINGLECHAR); }
		public TerminalNode SINGLECHAR(int i) {
			return getToken(Tex_grammarParser.SINGLECHAR, i);
		}
		public SumsuperscriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sumsuperscript; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSumsuperscript(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSumsuperscript(this);
		}
	}

	public final SumsuperscriptContext sumsuperscript() throws RecognitionException {
		SumsuperscriptContext _localctx = new SumsuperscriptContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_sumsuperscript);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(505);
			match(LEFTCURLYB);
			setState(506);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << ID) | (1L << EQUALTO))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)))) != 0)) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			setState(508);
			switch ( getInterpreter().adaptivePredict(_input,50,_ctx) ) {
			case 1:
				{
				setState(507);
				match(EQUALTO);
				}
				break;
			}
			setState(511);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << ID) | (1L << EQUALTO))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)))) != 0)) {
				{
				setState(510);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << ID) | (1L << EQUALTO))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)))) != 0)) ) {
				_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
			}

			setState(513);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MathdataContext extends ParserRuleContext {
		public TerminalNode LEFTCURLYB() { return getToken(Tex_grammarParser.LEFTCURLYB, 0); }
		public TerminalNode RIGHTCURLYB() { return getToken(Tex_grammarParser.RIGHTCURLYB, 0); }
		public TerminalNode EQUALTO() { return getToken(Tex_grammarParser.EQUALTO, 0); }
		public TerminalNode ID() { return getToken(Tex_grammarParser.ID, 0); }
		public TerminalNode WORD() { return getToken(Tex_grammarParser.WORD, 0); }
		public TerminalNode LETTERS() { return getToken(Tex_grammarParser.LETTERS, 0); }
		public TerminalNode SINGLECHAR() { return getToken(Tex_grammarParser.SINGLECHAR, 0); }
		public SqrtContext sqrt() {
			return getRuleContext(SqrtContext.class,0);
		}
		public SumContext sum() {
			return getRuleContext(SumContext.class,0);
		}
		public IntegralContext integral() {
			return getRuleContext(IntegralContext.class,0);
		}
		public MathdataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mathdata; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterMathdata(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitMathdata(this);
		}
	}

	public final MathdataContext mathdata() throws RecognitionException {
		MathdataContext _localctx = new MathdataContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_mathdata);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(515);
			match(LEFTCURLYB);
			setState(525);
			switch (_input.LA(1)) {
			case EQUALTO:
				{
				setState(516);
				match(EQUALTO);
				}
				break;
			case ID:
				{
				setState(517);
				match(ID);
				}
				break;
			case WORD:
				{
				setState(518);
				match(WORD);
				}
				break;
			case LETTERS:
				{
				setState(519);
				match(LETTERS);
				}
				break;
			case T__0:
				{
				setState(520);
				match(T__0);
				}
				break;
			case SINGLECHAR:
				{
				setState(521);
				match(SINGLECHAR);
				}
				break;
			case SQRT:
				{
				setState(522);
				sqrt();
				}
				break;
			case SUM:
				{
				setState(523);
				sum();
				}
				break;
			case INTEGRATION:
				{
				setState(524);
				integral();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(527);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FracdataContext extends ParserRuleContext {
		public List<FracPartContext> fracPart() {
			return getRuleContexts(FracPartContext.class);
		}
		public FracPartContext fracPart(int i) {
			return getRuleContext(FracPartContext.class,i);
		}
		public FracdataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fracdata; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterFracdata(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitFracdata(this);
		}
	}

	public final FracdataContext fracdata() throws RecognitionException {
		FracdataContext _localctx = new FracdataContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_fracdata);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(529);
			fracPart();
			setState(530);
			fracPart();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FracPartContext extends ParserRuleContext {
		public TerminalNode LEFTCURLYB() { return getToken(Tex_grammarParser.LEFTCURLYB, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public TerminalNode RIGHTCURLYB() { return getToken(Tex_grammarParser.RIGHTCURLYB, 0); }
		public SqrtContext sqrt() {
			return getRuleContext(SqrtContext.class,0);
		}
		public SumContext sum() {
			return getRuleContext(SumContext.class,0);
		}
		public IntegralContext integral() {
			return getRuleContext(IntegralContext.class,0);
		}
		public FracPartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fracPart; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterFracPart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitFracPart(this);
		}
	}

	public final FracPartContext fracPart() throws RecognitionException {
		FracPartContext _localctx = new FracPartContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_fracPart);
		try {
			setState(544);
			switch ( getInterpreter().adaptivePredict(_input,54,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(532);
				match(LEFTCURLYB);
				setState(533);
				text();
				setState(534);
				match(RIGHTCURLYB);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(536);
				match(LEFTCURLYB);
				setState(540);
				switch (_input.LA(1)) {
				case SQRT:
					{
					setState(537);
					sqrt();
					}
					break;
				case SUM:
					{
					setState(538);
					sum();
					}
					break;
				case INTEGRATION:
					{
					setState(539);
					integral();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(542);
				match(RIGHTCURLYB);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InlinemathContext extends ParserRuleContext {
		public List<TerminalNode> SINGLEDOLLAR() { return getTokens(Tex_grammarParser.SINGLEDOLLAR); }
		public TerminalNode SINGLEDOLLAR(int i) {
			return getToken(Tex_grammarParser.SINGLEDOLLAR, i);
		}
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public List<SuperscriptContext> superscript() {
			return getRuleContexts(SuperscriptContext.class);
		}
		public SuperscriptContext superscript(int i) {
			return getRuleContext(SuperscriptContext.class,i);
		}
		public List<IntegrationContext> integration() {
			return getRuleContexts(IntegrationContext.class);
		}
		public IntegrationContext integration(int i) {
			return getRuleContext(IntegrationContext.class,i);
		}
		public List<SubscriptContext> subscript() {
			return getRuleContexts(SubscriptContext.class);
		}
		public SubscriptContext subscript(int i) {
			return getRuleContext(SubscriptContext.class,i);
		}
		public List<SumContext> sum() {
			return getRuleContexts(SumContext.class);
		}
		public SumContext sum(int i) {
			return getRuleContext(SumContext.class,i);
		}
		public List<FracContext> frac() {
			return getRuleContexts(FracContext.class);
		}
		public FracContext frac(int i) {
			return getRuleContext(FracContext.class,i);
		}
		public List<SqrtContext> sqrt() {
			return getRuleContexts(SqrtContext.class);
		}
		public SqrtContext sqrt(int i) {
			return getRuleContext(SqrtContext.class,i);
		}
		public List<OperatorContext> operator() {
			return getRuleContexts(OperatorContext.class);
		}
		public OperatorContext operator(int i) {
			return getRuleContext(OperatorContext.class,i);
		}
		public InlinemathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inlinemath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterInlinemath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitInlinemath(this);
		}
	}

	public final InlinemathContext inlinemath() throws RecognitionException {
		InlinemathContext _localctx = new InlinemathContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_inlinemath);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(546);
			match(SINGLEDOLLAR);
			setState(557); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(557);
				switch (_input.LA(1)) {
				case T__0:
				case T__2:
				case ID:
				case LEFTPARENTHESES:
				case RIGHTPARENTHESES:
				case EQUALTO:
				case PLUS:
				case MUL:
				case WORD:
				case NEWLINE:
				case INTEGER:
				case SINGLECHAR:
				case LETTERS:
				case TEXT:
					{
					setState(547);
					text();
					}
					break;
				case SUPEQN:
					{
					setState(548);
					superscript();
					}
					break;
				case INTEGRATION:
					{
					setState(549);
					integration();
					}
					break;
				case SUBEQN:
					{
					setState(550);
					subscript();
					}
					break;
				case SUM:
					{
					setState(551);
					sum();
					}
					break;
				case FRAC:
					{
					setState(552);
					frac();
					}
					break;
				case SQRT:
					{
					setState(553);
					sqrt();
					setState(554);
					match(T__0);
					}
					break;
				case OPERATOR:
					{
					setState(556);
					operator();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(559); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__2) | (1L << ID) | (1L << FRAC) | (1L << SQRT) | (1L << SUM) | (1L << INTEGRATION) | (1L << LEFTPARENTHESES) | (1L << RIGHTPARENTHESES) | (1L << EQUALTO) | (1L << PLUS) | (1L << MUL) | (1L << SUPEQN) | (1L << SUBEQN))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (OPERATOR - 77)) | (1L << (NEWLINE - 77)) | (1L << (INTEGER - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)) | (1L << (TEXT - 77)))) != 0) );
			setState(561);
			match(SINGLEDOLLAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DisplaymathContext extends ParserRuleContext {
		public List<TerminalNode> DOUBLEDOLLAR() { return getTokens(Tex_grammarParser.DOUBLEDOLLAR); }
		public TerminalNode DOUBLEDOLLAR(int i) {
			return getToken(Tex_grammarParser.DOUBLEDOLLAR, i);
		}
		public List<SuperscriptContext> superscript() {
			return getRuleContexts(SuperscriptContext.class);
		}
		public SuperscriptContext superscript(int i) {
			return getRuleContext(SuperscriptContext.class,i);
		}
		public List<SubscriptContext> subscript() {
			return getRuleContexts(SubscriptContext.class);
		}
		public SubscriptContext subscript(int i) {
			return getRuleContext(SubscriptContext.class,i);
		}
		public List<SumContext> sum() {
			return getRuleContexts(SumContext.class);
		}
		public SumContext sum(int i) {
			return getRuleContext(SumContext.class,i);
		}
		public List<FracContext> frac() {
			return getRuleContexts(FracContext.class);
		}
		public FracContext frac(int i) {
			return getRuleContext(FracContext.class,i);
		}
		public List<SqrtContext> sqrt() {
			return getRuleContexts(SqrtContext.class);
		}
		public SqrtContext sqrt(int i) {
			return getRuleContext(SqrtContext.class,i);
		}
		public List<IntegrationContext> integration() {
			return getRuleContexts(IntegrationContext.class);
		}
		public IntegrationContext integration(int i) {
			return getRuleContext(IntegrationContext.class,i);
		}
		public List<TerminalNode> LEFTCURLYB() { return getTokens(Tex_grammarParser.LEFTCURLYB); }
		public TerminalNode LEFTCURLYB(int i) {
			return getToken(Tex_grammarParser.LEFTCURLYB, i);
		}
		public List<TerminalNode> RIGHTCURLYB() { return getTokens(Tex_grammarParser.RIGHTCURLYB); }
		public TerminalNode RIGHTCURLYB(int i) {
			return getToken(Tex_grammarParser.RIGHTCURLYB, i);
		}
		public List<TerminalNode> LEFTPARENTHESES() { return getTokens(Tex_grammarParser.LEFTPARENTHESES); }
		public TerminalNode LEFTPARENTHESES(int i) {
			return getToken(Tex_grammarParser.LEFTPARENTHESES, i);
		}
		public List<TerminalNode> RIGHTPARENTHESES() { return getTokens(Tex_grammarParser.RIGHTPARENTHESES); }
		public TerminalNode RIGHTPARENTHESES(int i) {
			return getToken(Tex_grammarParser.RIGHTPARENTHESES, i);
		}
		public List<OperatorContext> operator() {
			return getRuleContexts(OperatorContext.class);
		}
		public OperatorContext operator(int i) {
			return getRuleContext(OperatorContext.class,i);
		}
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public DisplaymathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_displaymath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterDisplaymath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitDisplaymath(this);
		}
	}

	public final DisplaymathContext displaymath() throws RecognitionException {
		DisplaymathContext _localctx = new DisplaymathContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_displaymath);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(563);
			match(DOUBLEDOLLAR);
			setState(586); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(586);
				switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
				case 1:
					{
					setState(564);
					superscript();
					}
					break;
				case 2:
					{
					setState(565);
					subscript();
					}
					break;
				case 3:
					{
					setState(566);
					sum();
					}
					break;
				case 4:
					{
					setState(567);
					frac();
					}
					break;
				case 5:
					{
					setState(568);
					sqrt();
					}
					break;
				case 6:
					{
					setState(569);
					integration();
					}
					break;
				case 7:
					{
					setState(571); 
					_errHandler.sync(this);
					_alt = 1;
					do {
						switch (_alt) {
						case 1:
							{
							{
							setState(570);
							text();
							}
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						setState(573); 
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,57,_ctx);
					} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
					}
					break;
				case 8:
					{
					setState(575);
					match(LEFTCURLYB);
					}
					break;
				case 9:
					{
					setState(576);
					match(RIGHTCURLYB);
					}
					break;
				case 10:
					{
					setState(577);
					match(LEFTPARENTHESES);
					}
					break;
				case 11:
					{
					setState(578);
					match(RIGHTPARENTHESES);
					}
					break;
				case 12:
					{
					setState(579);
					superscript();
					}
					break;
				case 13:
					{
					setState(580);
					subscript();
					}
					break;
				case 14:
					{
					setState(581);
					sum();
					}
					break;
				case 15:
					{
					setState(582);
					frac();
					}
					break;
				case 16:
					{
					setState(583);
					sqrt();
					}
					break;
				case 17:
					{
					setState(584);
					match(T__0);
					}
					break;
				case 18:
					{
					setState(585);
					operator();
					}
					break;
				}
				}
				setState(588); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__2) | (1L << ID) | (1L << FRAC) | (1L << SQRT) | (1L << SUM) | (1L << INTEGRATION) | (1L << LEFTCURLYB) | (1L << RIGHTCURLYB) | (1L << LEFTPARENTHESES) | (1L << RIGHTPARENTHESES) | (1L << EQUALTO) | (1L << PLUS) | (1L << MUL) | (1L << SUPEQN) | (1L << SUBEQN))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (OPERATOR - 77)) | (1L << (NEWLINE - 77)) | (1L << (INTEGER - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)) | (1L << (TEXT - 77)))) != 0) );
			setState(590);
			match(DOUBLEDOLLAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Begin_tableContext extends ParserRuleContext {
		public TerminalNode BEGIN_TABLE() { return getToken(Tex_grammarParser.BEGIN_TABLE, 0); }
		public Begin_tableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_begin_table; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterBegin_table(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitBegin_table(this);
		}
	}

	public final Begin_tableContext begin_table() throws RecognitionException {
		Begin_tableContext _localctx = new Begin_tableContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_begin_table);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(592);
			match(BEGIN_TABLE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class End_tableContext extends ParserRuleContext {
		public TerminalNode END_TABLE() { return getToken(Tex_grammarParser.END_TABLE, 0); }
		public End_tableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_end_table; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterEnd_table(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitEnd_table(this);
		}
	}

	public final End_tableContext end_table() throws RecognitionException {
		End_tableContext _localctx = new End_tableContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_end_table);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(594);
			match(END_TABLE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Begin_tabularContext extends ParserRuleContext {
		public TerminalNode BEGIN_TABULAR() { return getToken(Tex_grammarParser.BEGIN_TABULAR, 0); }
		public Begin_tabularContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_begin_tabular; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterBegin_tabular(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitBegin_tabular(this);
		}
	}

	public final Begin_tabularContext begin_tabular() throws RecognitionException {
		Begin_tabularContext _localctx = new Begin_tabularContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_begin_tabular);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(596);
			match(BEGIN_TABULAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class End_tabularContext extends ParserRuleContext {
		public TerminalNode END_TABULAR() { return getToken(Tex_grammarParser.END_TABULAR, 0); }
		public End_tabularContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_end_tabular; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterEnd_tabular(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitEnd_tabular(this);
		}
	}

	public final End_tabularContext end_tabular() throws RecognitionException {
		End_tabularContext _localctx = new End_tabularContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_end_tabular);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(598);
			match(END_TABULAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Table_alignmentContext extends ParserRuleContext {
		public TerminalNode TABLE_ALIGNMENT() { return getToken(Tex_grammarParser.TABLE_ALIGNMENT, 0); }
		public Table_alignmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table_alignment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterTable_alignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitTable_alignment(this);
		}
	}

	public final Table_alignmentContext table_alignment() throws RecognitionException {
		Table_alignmentContext _localctx = new Table_alignmentContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_table_alignment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(600);
			match(TABLE_ALIGNMENT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Table_rowContext extends ParserRuleContext {
		public DoubleslashContext doubleslash() {
			return getRuleContext(DoubleslashContext.class,0);
		}
		public List<Table_columnContext> table_column() {
			return getRuleContexts(Table_columnContext.class);
		}
		public Table_columnContext table_column(int i) {
			return getRuleContext(Table_columnContext.class,i);
		}
		public Table_rowContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table_row; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterTable_row(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitTable_row(this);
		}
	}

	public final Table_rowContext table_row() throws RecognitionException {
		Table_rowContext _localctx = new Table_rowContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_table_row);
		try {
			int _alt;
			setState(649);
			switch (_input.LA(1)) {
			case T__0:
			case T__2:
			case T__3:
			case ID:
			case LEFTPARENTHESES:
			case RIGHTPARENTHESES:
			case EQUALTO:
			case PLUS:
			case MUL:
			case AMPERSAND:
			case WORD:
			case NEWLINE:
			case INTEGER:
			case SINGLECHAR:
			case LETTERS:
			case TEXT:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(623); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(605);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,60,_ctx);
						while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
							if ( _alt==1 ) {
								{
								{
								setState(602);
								match(T__0);
								}
								} 
							}
							setState(607);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,60,_ctx);
						}
						setState(614); 
						_errHandler.sync(this);
						_alt = 1;
						do {
							switch (_alt) {
							case 1:
								{
								{
								setState(608);
								table_column();
								setState(610); 
								_errHandler.sync(this);
								_alt = 1;
								do {
									switch (_alt) {
									case 1:
										{
										{
										setState(609);
										match(T__0);
										}
										}
										break;
									default:
										throw new NoViableAltException(this);
									}
									setState(612); 
									_errHandler.sync(this);
									_alt = getInterpreter().adaptivePredict(_input,61,_ctx);
								} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
								}
								}
								break;
							default:
								throw new NoViableAltException(this);
							}
							setState(616); 
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,62,_ctx);
						} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
						setState(619); 
						_errHandler.sync(this);
						_alt = 1;
						do {
							switch (_alt) {
							case 1:
								{
								{
								setState(618);
								match(T__0);
								}
								}
								break;
							default:
								throw new NoViableAltException(this);
							}
							setState(621); 
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,63,_ctx);
						} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(625); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,64,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(630);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,65,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(627);
						match(T__3);
						}
						} 
					}
					setState(632);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,65,_ctx);
				}
				setState(636);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,66,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(633);
						match(T__0);
						}
						} 
					}
					setState(638);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,66,_ctx);
				}
				}
				setState(640);
				switch ( getInterpreter().adaptivePredict(_input,67,_ctx) ) {
				case 1:
					{
					setState(639);
					doubleslash();
					}
					break;
				}
				}
				break;
			case DOUBLESLASH:
				enterOuterAlt(_localctx, 2);
				{
				setState(642);
				match(DOUBLESLASH);
				setState(646);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,68,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(643);
						match(T__0);
						}
						} 
					}
					setState(648);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,68,_ctx);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DoubleslashContext extends ParserRuleContext {
		public TerminalNode DOUBLESLASH() { return getToken(Tex_grammarParser.DOUBLESLASH, 0); }
		public DoubleslashContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_doubleslash; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterDoubleslash(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitDoubleslash(this);
		}
	}

	public final DoubleslashContext doubleslash() throws RecognitionException {
		DoubleslashContext _localctx = new DoubleslashContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_doubleslash);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(651);
			match(DOUBLESLASH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Table_columnContext extends ParserRuleContext {
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public TerminalNode AMPERSAND() { return getToken(Tex_grammarParser.AMPERSAND, 0); }
		public Table_columnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table_column; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterTable_column(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitTable_column(this);
		}
	}

	public final Table_columnContext table_column() throws RecognitionException {
		Table_columnContext _localctx = new Table_columnContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_table_column);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(656);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,70,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(653);
					_la = _input.LA(1);
					if ( !(_la==T__0 || _la==T__3) ) {
					_errHandler.recoverInline(this);
					} else {
						consume();
					}
					}
					} 
				}
				setState(658);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,70,_ctx);
			}
			setState(662);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,71,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(659);
					text();
					}
					} 
				}
				setState(664);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,71,_ctx);
			}
			setState(668);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,72,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(665);
					_la = _input.LA(1);
					if ( !(_la==T__0 || _la==T__3) ) {
					_errHandler.recoverInline(this);
					} else {
						consume();
					}
					}
					} 
				}
				setState(670);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,72,_ctx);
			}
			setState(672);
			_la = _input.LA(1);
			if (_la==AMPERSAND) {
				{
				setState(671);
				match(AMPERSAND);
				}
			}

			setState(677);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,74,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(674);
					_la = _input.LA(1);
					if ( !(_la==T__0 || _la==T__3) ) {
					_errHandler.recoverInline(this);
					} else {
						consume();
					}
					}
					} 
				}
				setState(679);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,74,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TableContext extends ParserRuleContext {
		public Begin_tabularContext begin_tabular() {
			return getRuleContext(Begin_tabularContext.class,0);
		}
		public End_tabularContext end_tabular() {
			return getRuleContext(End_tabularContext.class,0);
		}
		public List<Table_rowContext> table_row() {
			return getRuleContexts(Table_rowContext.class);
		}
		public Table_rowContext table_row(int i) {
			return getRuleContext(Table_rowContext.class,i);
		}
		public Begin_tableContext begin_table() {
			return getRuleContext(Begin_tableContext.class,0);
		}
		public Table_alignmentContext table_alignment() {
			return getRuleContext(Table_alignmentContext.class,0);
		}
		public End_tableContext end_table() {
			return getRuleContext(End_tableContext.class,0);
		}
		public List<DoubleslashContext> doubleslash() {
			return getRuleContexts(DoubleslashContext.class);
		}
		public DoubleslashContext doubleslash(int i) {
			return getRuleContext(DoubleslashContext.class,i);
		}
		public TableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_table; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterTable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitTable(this);
		}
	}

	public final TableContext table() throws RecognitionException {
		TableContext _localctx = new TableContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_table);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(681);
			_la = _input.LA(1);
			if (_la==BEGIN_TABLE) {
				{
				setState(680);
				begin_table();
				}
			}

			setState(683);
			begin_tabular();
			setState(685);
			_la = _input.LA(1);
			if (_la==TABLE_ALIGNMENT) {
				{
				setState(684);
				table_alignment();
				}
			}

			}
			setState(697); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(687);
				table_row();
				setState(691);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,77,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(688);
						match(T__0);
						}
						} 
					}
					setState(693);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,77,_ctx);
				}
				setState(695);
				switch ( getInterpreter().adaptivePredict(_input,78,_ctx) ) {
				case 1:
					{
					setState(694);
					doubleslash();
					}
					break;
				}
				}
				}
				setState(699); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__2) | (1L << T__3) | (1L << ID) | (1L << DOUBLESLASH) | (1L << LEFTPARENTHESES) | (1L << RIGHTPARENTHESES) | (1L << EQUALTO) | (1L << PLUS) | (1L << MUL) | (1L << AMPERSAND))) != 0) || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (NEWLINE - 77)) | (1L << (INTEGER - 77)) | (1L << (SINGLECHAR - 77)) | (1L << (LETTERS - 77)) | (1L << (TEXT - 77)))) != 0) );
			{
			setState(701);
			end_tabular();
			setState(703);
			switch ( getInterpreter().adaptivePredict(_input,80,_ctx) ) {
			case 1:
				{
				setState(702);
				end_table();
				}
				break;
			}
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Latex_newlineContext extends ParserRuleContext {
		public TerminalNode DOUBLESLASH() { return getToken(Tex_grammarParser.DOUBLESLASH, 0); }
		public TerminalNode LATEX_NEWLINE() { return getToken(Tex_grammarParser.LATEX_NEWLINE, 0); }
		public TerminalNode HFILL() { return getToken(Tex_grammarParser.HFILL, 0); }
		public TerminalNode BREAK() { return getToken(Tex_grammarParser.BREAK, 0); }
		public Latex_newlineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_latex_newline; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterLatex_newline(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitLatex_newline(this);
		}
	}

	public final Latex_newlineContext latex_newline() throws RecognitionException {
		Latex_newlineContext _localctx = new Latex_newlineContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_latex_newline);
		int _la;
		try {
			setState(715);
			switch (_input.LA(1)) {
			case DOUBLESLASH:
				enterOuterAlt(_localctx, 1);
				{
				setState(705);
				match(DOUBLESLASH);
				}
				break;
			case LATEX_NEWLINE:
				enterOuterAlt(_localctx, 2);
				{
				setState(706);
				match(LATEX_NEWLINE);
				}
				break;
			case HFILL:
				enterOuterAlt(_localctx, 3);
				{
				setState(707);
				match(HFILL);
				setState(711);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(708);
					match(T__0);
					}
					}
					setState(713);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(714);
				match(BREAK);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BoldtextContext extends ParserRuleContext {
		public TerminalNode TEXTBF() { return getToken(Tex_grammarParser.TEXTBF, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public BoldtextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boldtext; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterBoldtext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitBoldtext(this);
		}
	}

	public final BoldtextContext boldtext() throws RecognitionException {
		BoldtextContext _localctx = new BoldtextContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_boldtext);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(717);
			match(TEXTBF);
			setState(718);
			match(LEFTCURLYB);
			setState(719);
			text();
			setState(720);
			match(RIGHTCURLYB);
			setState(724);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,83,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(721);
					match(T__0);
					}
					} 
				}
				setState(726);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,83,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ItalictextContext extends ParserRuleContext {
		public TerminalNode TEXTIT() { return getToken(Tex_grammarParser.TEXTIT, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public ItalictextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_italictext; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterItalictext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitItalictext(this);
		}
	}

	public final ItalictextContext italictext() throws RecognitionException {
		ItalictextContext _localctx = new ItalictextContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_italictext);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(727);
			match(TEXTIT);
			setState(728);
			match(LEFTCURLYB);
			setState(729);
			text();
			setState(730);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnderlineContext extends ParserRuleContext {
		public TerminalNode UNDERLINE() { return getToken(Tex_grammarParser.UNDERLINE, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public UnderlineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_underline; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterUnderline(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitUnderline(this);
		}
	}

	public final UnderlineContext underline() throws RecognitionException {
		UnderlineContext _localctx = new UnderlineContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_underline);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(732);
			match(UNDERLINE);
			setState(733);
			match(LEFTCURLYB);
			setState(734);
			text();
			setState(735);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CaptionContext extends ParserRuleContext {
		public TerminalNode CAPTION() { return getToken(Tex_grammarParser.CAPTION, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public CaptionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caption; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterCaption(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitCaption(this);
		}
	}

	public final CaptionContext caption() throws RecognitionException {
		CaptionContext _localctx = new CaptionContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_caption);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(737);
			match(CAPTION);
			setState(738);
			match(LEFTCURLYB);
			setState(739);
			expr(0);
			setState(740);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelContext extends ParserRuleContext {
		public TerminalNode LABEL() { return getToken(Tex_grammarParser.LABEL, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public LabelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_label; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterLabel(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitLabel(this);
		}
	}

	public final LabelContext label() throws RecognitionException {
		LabelContext _localctx = new LabelContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_label);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(742);
			match(LABEL);
			setState(743);
			match(LEFTCURLYB);
			setState(744);
			text();
			setState(745);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RefContext extends ParserRuleContext {
		public TerminalNode REF() { return getToken(Tex_grammarParser.REF, 0); }
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public RefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ref; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitRef(this);
		}
	}

	public final RefContext ref() throws RecognitionException {
		RefContext _localctx = new RefContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_ref);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(747);
			match(REF);
			setState(748);
			match(LEFTCURLYB);
			setState(749);
			text();
			setState(750);
			match(RIGHTCURLYB);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TextContext extends ParserRuleContext {
		public TerminalNode TEXT() { return getToken(Tex_grammarParser.TEXT, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(Tex_grammarParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(Tex_grammarParser.NEWLINE, i);
		}
		public TerminalNode WORD() { return getToken(Tex_grammarParser.WORD, 0); }
		public TerminalNode INTEGER() { return getToken(Tex_grammarParser.INTEGER, 0); }
		public TerminalNode LETTERS() { return getToken(Tex_grammarParser.LETTERS, 0); }
		public TerminalNode SINGLECHAR() { return getToken(Tex_grammarParser.SINGLECHAR, 0); }
		public TerminalNode EQUALTO() { return getToken(Tex_grammarParser.EQUALTO, 0); }
		public TerminalNode PLUS() { return getToken(Tex_grammarParser.PLUS, 0); }
		public TerminalNode MUL() { return getToken(Tex_grammarParser.MUL, 0); }
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public TextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_text; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitText(this);
		}
	}

	public final TextContext text() throws RecognitionException {
		TextContext _localctx = new TextContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_text);
		int _la;
		try {
			setState(772);
			switch ( getInterpreter().adaptivePredict(_input,85,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(755);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE) {
					{
					{
					setState(752);
					match(NEWLINE);
					}
					}
					setState(757);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(758);
				match(TEXT);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(759);
				match(WORD);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(760);
				match(INTEGER);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(761);
				match(LETTERS);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(762);
				match(T__2);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(763);
				match(T__0);
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(764);
				match(SINGLECHAR);
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(765);
				match(EQUALTO);
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(766);
				match(PLUS);
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(767);
				match(MUL);
				}
				break;
			case 11:
				enterOuterAlt(_localctx, 11);
				{
				setState(768);
				match(EQUALTO);
				}
				break;
			case 12:
				enterOuterAlt(_localctx, 12);
				{
				setState(769);
				stat();
				}
				break;
			case 13:
				enterOuterAlt(_localctx, 13);
				{
				setState(770);
				match(LEFTPARENTHESES);
				}
				break;
			case 14:
				enterOuterAlt(_localctx, 14);
				{
				setState(771);
				match(RIGHTPARENTHESES);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FulltextContext extends ParserRuleContext {
		public List<TextContext> text() {
			return getRuleContexts(TextContext.class);
		}
		public TextContext text(int i) {
			return getRuleContext(TextContext.class,i);
		}
		public UnderlineContext underline() {
			return getRuleContext(UnderlineContext.class,0);
		}
		public BoldtextContext boldtext() {
			return getRuleContext(BoldtextContext.class,0);
		}
		public ItalictextContext italictext() {
			return getRuleContext(ItalictextContext.class,0);
		}
		public InlinemathContext inlinemath() {
			return getRuleContext(InlinemathContext.class,0);
		}
		public DisplaymathContext displaymath() {
			return getRuleContext(DisplaymathContext.class,0);
		}
		public TableContext table() {
			return getRuleContext(TableContext.class,0);
		}
		public CaptionContext caption() {
			return getRuleContext(CaptionContext.class,0);
		}
		public FracContext frac() {
			return getRuleContext(FracContext.class,0);
		}
		public SqrtContext sqrt() {
			return getRuleContext(SqrtContext.class,0);
		}
		public SumContext sum() {
			return getRuleContext(SumContext.class,0);
		}
		public IntegrationContext integration() {
			return getRuleContext(IntegrationContext.class,0);
		}
		public LabelContext label() {
			return getRuleContext(LabelContext.class,0);
		}
		public RefContext ref() {
			return getRuleContext(RefContext.class,0);
		}
		public ParContext par() {
			return getRuleContext(ParContext.class,0);
		}
		public CenterContext center() {
			return getRuleContext(CenterContext.class,0);
		}
		public List<Latex_newlineContext> latex_newline() {
			return getRuleContexts(Latex_newlineContext.class);
		}
		public Latex_newlineContext latex_newline(int i) {
			return getRuleContext(Latex_newlineContext.class,i);
		}
		public FulltextContext fulltext() {
			return getRuleContext(FulltextContext.class,0);
		}
		public FulltextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fulltext; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterFulltext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitFulltext(this);
		}
	}

	public final FulltextContext fulltext() throws RecognitionException {
		return fulltext(0);
	}

	private FulltextContext fulltext(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		FulltextContext _localctx = new FulltextContext(_ctx, _parentState);
		FulltextContext _prevctx = _localctx;
		int _startState = 122;
		enterRecursionRule(_localctx, 122, RULE_fulltext, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(818);
			switch ( getInterpreter().adaptivePredict(_input,89,_ctx) ) {
			case 1:
				{
				setState(775);
				text();
				setState(776);
				underline();
				}
				break;
			case 2:
				{
				setState(778);
				text();
				setState(779);
				boldtext();
				}
				break;
			case 3:
				{
				setState(781);
				text();
				setState(782);
				italictext();
				}
				break;
			case 4:
				{
				setState(784);
				inlinemath();
				}
				break;
			case 5:
				{
				setState(785);
				displaymath();
				}
				break;
			case 6:
				{
				setState(786);
				table();
				}
				break;
			case 7:
				{
				setState(787);
				boldtext();
				}
				break;
			case 8:
				{
				setState(788);
				italictext();
				}
				break;
			case 9:
				{
				setState(789);
				underline();
				}
				break;
			case 10:
				{
				setState(790);
				caption();
				}
				break;
			case 11:
				{
				setState(791);
				frac();
				}
				break;
			case 12:
				{
				setState(792);
				sqrt();
				}
				break;
			case 13:
				{
				setState(793);
				sum();
				}
				break;
			case 14:
				{
				setState(794);
				integration();
				}
				break;
			case 15:
				{
				setState(795);
				label();
				}
				break;
			case 16:
				{
				setState(796);
				ref();
				}
				break;
			case 17:
				{
				setState(797);
				par();
				}
				break;
			case 18:
				{
				setState(798);
				center();
				}
				break;
			case 19:
				{
				setState(802);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << DOUBLESLASH) | (1L << LATEX_NEWLINE) | (1L << HFILL))) != 0)) {
					{
					{
					setState(799);
					latex_newline();
					}
					}
					setState(804);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(805);
				text();
				setState(809);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,87,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(806);
						latex_newline();
						}
						} 
					}
					setState(811);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,87,_ctx);
				}
				setState(815);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,88,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(812);
						text();
						}
						} 
					}
					setState(817);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,88,_ctx);
				}
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(869);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,95,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(867);
					switch ( getInterpreter().adaptivePredict(_input,94,_ctx) ) {
					case 1:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(820);
						if (!(precpred(_ctx, 35))) throw new FailedPredicateException(this, "precpred(_ctx, 35)");
						setState(824);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,90,_ctx);
						while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
							if ( _alt==1 ) {
								{
								{
								setState(821);
								match(T__0);
								}
								} 
							}
							setState(826);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,90,_ctx);
						}
						setState(827);
						text();
						}
						break;
					case 2:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(828);
						if (!(precpred(_ctx, 34))) throw new FailedPredicateException(this, "precpred(_ctx, 34)");
						setState(829);
						boldtext();
						setState(831);
						switch ( getInterpreter().adaptivePredict(_input,91,_ctx) ) {
						case 1:
							{
							setState(830);
							text();
							}
							break;
						}
						}
						break;
					case 3:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(833);
						if (!(precpred(_ctx, 33))) throw new FailedPredicateException(this, "precpred(_ctx, 33)");
						setState(834);
						italictext();
						setState(836);
						switch ( getInterpreter().adaptivePredict(_input,92,_ctx) ) {
						case 1:
							{
							setState(835);
							text();
							}
							break;
						}
						}
						break;
					case 4:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(838);
						if (!(precpred(_ctx, 32))) throw new FailedPredicateException(this, "precpred(_ctx, 32)");
						setState(839);
						underline();
						setState(841);
						switch ( getInterpreter().adaptivePredict(_input,93,_ctx) ) {
						case 1:
							{
							setState(840);
							text();
							}
							break;
						}
						}
						break;
					case 5:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(843);
						if (!(precpred(_ctx, 31))) throw new FailedPredicateException(this, "precpred(_ctx, 31)");
						setState(844);
						caption();
						}
						break;
					case 6:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(845);
						if (!(precpred(_ctx, 30))) throw new FailedPredicateException(this, "precpred(_ctx, 30)");
						setState(846);
						frac();
						}
						break;
					case 7:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(847);
						if (!(precpred(_ctx, 29))) throw new FailedPredicateException(this, "precpred(_ctx, 29)");
						setState(848);
						sqrt();
						}
						break;
					case 8:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(849);
						if (!(precpred(_ctx, 28))) throw new FailedPredicateException(this, "precpred(_ctx, 28)");
						setState(850);
						sum();
						}
						break;
					case 9:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(851);
						if (!(precpred(_ctx, 27))) throw new FailedPredicateException(this, "precpred(_ctx, 27)");
						setState(852);
						integration();
						}
						break;
					case 10:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(853);
						if (!(precpred(_ctx, 26))) throw new FailedPredicateException(this, "precpred(_ctx, 26)");
						setState(854);
						inlinemath();
						}
						break;
					case 11:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(855);
						if (!(precpred(_ctx, 25))) throw new FailedPredicateException(this, "precpred(_ctx, 25)");
						setState(856);
						displaymath();
						}
						break;
					case 12:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(857);
						if (!(precpred(_ctx, 24))) throw new FailedPredicateException(this, "precpred(_ctx, 24)");
						setState(858);
						table();
						}
						break;
					case 13:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(859);
						if (!(precpred(_ctx, 23))) throw new FailedPredicateException(this, "precpred(_ctx, 23)");
						setState(860);
						label();
						}
						break;
					case 14:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(861);
						if (!(precpred(_ctx, 22))) throw new FailedPredicateException(this, "precpred(_ctx, 22)");
						setState(862);
						ref();
						}
						break;
					case 15:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(863);
						if (!(precpred(_ctx, 21))) throw new FailedPredicateException(this, "precpred(_ctx, 21)");
						setState(864);
						center();
						}
						break;
					case 16:
						{
						_localctx = new FulltextContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_fulltext);
						setState(865);
						if (!(precpred(_ctx, 20))) throw new FailedPredicateException(this, "precpred(_ctx, 20)");
						setState(866);
						par();
						}
						break;
					}
					} 
				}
				setState(871);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,95,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class WordContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(Tex_grammarParser.WORD, 0); }
		public WordContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_word; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterWord(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitWord(this);
		}
	}

	public final WordContext word() throws RecognitionException {
		WordContext _localctx = new WordContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_word);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(872);
			match(WORD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LetterContext extends ParserRuleContext {
		public TerminalNode LETTERS() { return getToken(Tex_grammarParser.LETTERS, 0); }
		public LetterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_letter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterLetter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitLetter(this);
		}
	}

	public final LetterContext letter() throws RecognitionException {
		LetterContext _localctx = new LetterContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_letter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(874);
			match(LETTERS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntegerContext extends ParserRuleContext {
		public TerminalNode INTEGER() { return getToken(Tex_grammarParser.INTEGER, 0); }
		public IntegerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterInteger(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitInteger(this);
		}
	}

	public final IntegerContext integer() throws RecognitionException {
		IntegerContext _localctx = new IntegerContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_integer);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(876);
			match(INTEGER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SentenceContext extends ParserRuleContext {
		public List<WordContext> word() {
			return getRuleContexts(WordContext.class);
		}
		public WordContext word(int i) {
			return getRuleContext(WordContext.class,i);
		}
		public List<LetterContext> letter() {
			return getRuleContexts(LetterContext.class);
		}
		public LetterContext letter(int i) {
			return getRuleContext(LetterContext.class,i);
		}
		public List<IntegerContext> integer() {
			return getRuleContexts(IntegerContext.class);
		}
		public IntegerContext integer(int i) {
			return getRuleContext(IntegerContext.class,i);
		}
		public SentenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sentence; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterSentence(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitSentence(this);
		}
	}

	public final SentenceContext sentence() throws RecognitionException {
		SentenceContext _localctx = new SentenceContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_sentence);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(882); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(882);
				switch (_input.LA(1)) {
				case WORD:
					{
					setState(878);
					word();
					}
					break;
				case LETTERS:
					{
					setState(879);
					letter();
					}
					break;
				case INTEGER:
					{
					setState(880);
					integer();
					}
					break;
				case T__0:
					{
					setState(881);
					match(T__0);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(884); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 || ((((_la - 77)) & ~0x3f) == 0 && ((1L << (_la - 77)) & ((1L << (WORD - 77)) | (1L << (INTEGER - 77)) | (1L << (LETTERS - 77)))) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LineContext extends ParserRuleContext {
		public List<TerminalNode> WORD() { return getTokens(Tex_grammarParser.WORD); }
		public TerminalNode WORD(int i) {
			return getToken(Tex_grammarParser.WORD, i);
		}
		public LineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_line; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).enterLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Tex_grammarListener ) ((Tex_grammarListener)listener).exitLine(this);
		}
	}

	public final LineContext line() throws RecognitionException {
		LineContext _localctx = new LineContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_line);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(889);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0 || _la==T__3) {
				{
				{
				setState(886);
				_la = _input.LA(1);
				if ( !(_la==T__0 || _la==T__3) ) {
				_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
				}
				setState(891);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(901);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WORD) {
				{
				{
				setState(892);
				match(WORD);
				setState(896);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0 || _la==T__3) {
					{
					{
					setState(893);
					_la = _input.LA(1);
					if ( !(_la==T__0 || _la==T__3) ) {
					_errHandler.recoverInline(this);
					} else {
						consume();
					}
					}
					}
					setState(898);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(903);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(904);
			_la = _input.LA(1);
			if ( !(_la==T__4 || _la==T__5 || _la==SKIP2) ) {
			_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 5:
			return body_text_sempred((Body_textContext)_localctx, predIndex);
		case 27:
			return expr_sempred((ExprContext)_localctx, predIndex);
		case 61:
			return fulltext_sempred((FulltextContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean body_text_sempred(Body_textContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 2);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return precpred(_ctx, 4);
		}
		return true;
	}
	private boolean fulltext_sempred(FulltextContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return precpred(_ctx, 35);
		case 3:
			return precpred(_ctx, 34);
		case 4:
			return precpred(_ctx, 33);
		case 5:
			return precpred(_ctx, 32);
		case 6:
			return precpred(_ctx, 31);
		case 7:
			return precpred(_ctx, 30);
		case 8:
			return precpred(_ctx, 29);
		case 9:
			return precpred(_ctx, 28);
		case 10:
			return precpred(_ctx, 27);
		case 11:
			return precpred(_ctx, 26);
		case 12:
			return precpred(_ctx, 25);
		case 13:
			return precpred(_ctx, 24);
		case 14:
			return precpred(_ctx, 23);
		case 15:
			return precpred(_ctx, 22);
		case 16:
			return precpred(_ctx, 21);
		case 17:
			return precpred(_ctx, 20);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3Z\u038d\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4"+
		",\t,\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\4\64\t"+
		"\64\4\65\t\65\4\66\t\66\4\67\t\67\48\t8\49\t9\4:\t:\4;\t;\4<\t<\4=\t="+
		"\4>\t>\4?\t?\4@\t@\4A\tA\4B\tB\4C\tC\4D\tD\3\2\3\2\7\2\u008b\n\2\f\2\16"+
		"\2\u008e\13\2\3\2\3\2\7\2\u0092\n\2\f\2\16\2\u0095\13\2\3\2\7\2\u0098"+
		"\n\2\f\2\16\2\u009b\13\2\3\2\7\2\u009e\n\2\f\2\16\2\u00a1\13\2\3\2\3\2"+
		"\3\2\3\2\3\3\3\3\3\4\3\4\3\5\3\5\3\6\3\6\3\7\3\7\3\7\3\7\3\7\7\7\u00b4"+
		"\n\7\f\7\16\7\u00b7\13\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\5\b\u00c3"+
		"\n\b\3\t\3\t\7\t\u00c7\n\t\f\t\16\t\u00ca\13\t\3\n\3\n\7\n\u00ce\n\n\f"+
		"\n\16\n\u00d1\13\n\3\13\3\13\7\13\u00d5\n\13\f\13\16\13\u00d8\13\13\3"+
		"\f\3\f\3\r\3\r\7\r\u00de\n\r\f\r\16\r\u00e1\13\r\3\r\3\r\7\r\u00e5\n\r"+
		"\f\r\16\r\u00e8\13\r\3\r\3\r\3\16\3\16\7\16\u00ee\n\16\f\16\16\16\u00f1"+
		"\13\16\3\16\7\16\u00f4\n\16\f\16\16\16\u00f7\13\16\3\16\7\16\u00fa\n\16"+
		"\f\16\16\16\u00fd\13\16\3\17\3\17\7\17\u0101\n\17\f\17\16\17\u0104\13"+
		"\17\3\17\3\17\3\17\3\17\7\17\u010a\n\17\f\17\16\17\u010d\13\17\3\20\3"+
		"\20\3\20\7\20\u0112\n\20\f\20\16\20\u0115\13\20\3\20\7\20\u0118\n\20\f"+
		"\20\16\20\u011b\13\20\3\21\3\21\7\21\u011f\n\21\f\21\16\21\u0122\13\21"+
		"\3\21\3\21\3\21\3\21\7\21\u0128\n\21\f\21\16\21\u012b\13\21\3\22\3\22"+
		"\3\23\3\23\7\23\u0131\n\23\f\23\16\23\u0134\13\23\3\23\3\23\3\24\3\24"+
		"\3\24\3\24\3\25\3\25\3\25\3\25\7\25\u0140\n\25\f\25\16\25\u0143\13\25"+
		"\3\26\3\26\5\26\u0147\n\26\3\26\3\26\7\26\u014b\n\26\f\26\16\26\u014e"+
		"\13\26\3\27\3\27\3\27\5\27\u0153\n\27\3\27\5\27\u0156\n\27\3\27\5\27\u0159"+
		"\n\27\3\27\3\27\3\27\3\27\5\27\u015f\n\27\3\27\3\27\3\27\5\27\u0164\n"+
		"\27\3\30\3\30\6\30\u0168\n\30\r\30\16\30\u0169\3\30\3\30\3\31\3\31\6\31"+
		"\u0170\n\31\r\31\16\31\u0171\3\31\3\31\3\32\3\32\6\32\u0178\n\32\r\32"+
		"\16\32\u0179\3\32\3\32\3\32\3\32\3\32\3\32\5\32\u0182\n\32\3\33\7\33\u0185"+
		"\n\33\f\33\16\33\u0188\13\33\3\33\7\33\u018b\n\33\f\33\16\33\u018e\13"+
		"\33\3\33\7\33\u0191\n\33\f\33\16\33\u0194\13\33\3\34\3\34\5\34\u0198\n"+
		"\34\3\34\3\34\3\34\3\34\5\34\u019e\n\34\3\34\5\34\u01a1\n\34\3\35\3\35"+
		"\3\35\3\35\3\35\3\35\3\35\5\35\u01aa\n\35\3\35\3\35\3\35\7\35\u01af\n"+
		"\35\f\35\16\35\u01b2\13\35\3\36\3\36\3\37\3\37\3 \3 \3!\3!\3!\7!\u01bd"+
		"\n!\f!\16!\u01c0\13!\3\"\3\"\3\"\7\"\u01c5\n\"\f\"\16\"\u01c8\13\"\3\""+
		"\3\"\3\"\3\"\5\"\u01ce\n\"\3#\3#\3#\3#\3#\3#\7#\u01d6\n#\f#\16#\u01d9"+
		"\13#\3$\3$\3%\3%\3%\3%\3%\3%\7%\u01e3\n%\f%\16%\u01e6\13%\3%\5%\u01e9"+
		"\n%\3&\3&\7&\u01ed\n&\f&\16&\u01f0\13&\3\'\3\'\3\'\5\'\u01f5\n\'\3\'\5"+
		"\'\u01f8\n\'\3\'\3\'\3(\3(\3(\5(\u01ff\n(\3(\5(\u0202\n(\3(\3(\3)\3)\3"+
		")\3)\3)\3)\3)\3)\3)\3)\5)\u0210\n)\3)\3)\3*\3*\3*\3+\3+\3+\3+\3+\3+\3"+
		"+\3+\5+\u021f\n+\3+\3+\5+\u0223\n+\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\6"+
		",\u0230\n,\r,\16,\u0231\3,\3,\3-\3-\3-\3-\3-\3-\3-\3-\6-\u023e\n-\r-\16"+
		"-\u023f\3-\3-\3-\3-\3-\3-\3-\3-\3-\3-\3-\6-\u024d\n-\r-\16-\u024e\3-\3"+
		"-\3.\3.\3/\3/\3\60\3\60\3\61\3\61\3\62\3\62\3\63\7\63\u025e\n\63\f\63"+
		"\16\63\u0261\13\63\3\63\3\63\6\63\u0265\n\63\r\63\16\63\u0266\6\63\u0269"+
		"\n\63\r\63\16\63\u026a\3\63\6\63\u026e\n\63\r\63\16\63\u026f\6\63\u0272"+
		"\n\63\r\63\16\63\u0273\3\63\7\63\u0277\n\63\f\63\16\63\u027a\13\63\3\63"+
		"\7\63\u027d\n\63\f\63\16\63\u0280\13\63\3\63\5\63\u0283\n\63\3\63\3\63"+
		"\7\63\u0287\n\63\f\63\16\63\u028a\13\63\5\63\u028c\n\63\3\64\3\64\3\65"+
		"\7\65\u0291\n\65\f\65\16\65\u0294\13\65\3\65\7\65\u0297\n\65\f\65\16\65"+
		"\u029a\13\65\3\65\7\65\u029d\n\65\f\65\16\65\u02a0\13\65\3\65\5\65\u02a3"+
		"\n\65\3\65\7\65\u02a6\n\65\f\65\16\65\u02a9\13\65\3\66\5\66\u02ac\n\66"+
		"\3\66\3\66\5\66\u02b0\n\66\3\66\3\66\7\66\u02b4\n\66\f\66\16\66\u02b7"+
		"\13\66\3\66\5\66\u02ba\n\66\6\66\u02bc\n\66\r\66\16\66\u02bd\3\66\3\66"+
		"\5\66\u02c2\n\66\3\67\3\67\3\67\3\67\7\67\u02c8\n\67\f\67\16\67\u02cb"+
		"\13\67\3\67\5\67\u02ce\n\67\38\38\38\38\38\78\u02d5\n8\f8\168\u02d8\13"+
		"8\39\39\39\39\39\3:\3:\3:\3:\3:\3;\3;\3;\3;\3;\3<\3<\3<\3<\3<\3=\3=\3"+
		"=\3=\3=\3>\7>\u02f4\n>\f>\16>\u02f7\13>\3>\3>\3>\3>\3>\3>\3>\3>\3>\3>"+
		"\3>\3>\3>\3>\5>\u0307\n>\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?"+
		"\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\7?\u0323\n?\f?\16?\u0326\13?\3?\3?\7"+
		"?\u032a\n?\f?\16?\u032d\13?\3?\7?\u0330\n?\f?\16?\u0333\13?\5?\u0335\n"+
		"?\3?\3?\7?\u0339\n?\f?\16?\u033c\13?\3?\3?\3?\3?\5?\u0342\n?\3?\3?\3?"+
		"\5?\u0347\n?\3?\3?\3?\5?\u034c\n?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?"+
		"\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\3?\7?\u0366\n?\f?\16?\u0369\13?\3@\3"+
		"@\3A\3A\3B\3B\3C\3C\3C\3C\6C\u0375\nC\rC\16C\u0376\3D\7D\u037a\nD\fD\16"+
		"D\u037d\13D\3D\3D\7D\u0381\nD\fD\16D\u0384\13D\7D\u0386\nD\fD\16D\u0389"+
		"\13D\3D\3D\3D\2\5\f8|E\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,"+
		".\60\62\64\668:<>@BDFHJLNPRTVXZ\\^`bdfhjlnprtvxz|~\u0080\u0082\u0084\u0086"+
		"\2\b\3\2#,\4\2\3\3TT\4\2\4\5\31\32\7\2\3\3\t\t\30\30OOXY\4\2\3\3\6\6\4"+
		"\2\7\bTT\u0406\2\u0088\3\2\2\2\4\u00a6\3\2\2\2\6\u00a8\3\2\2\2\b\u00aa"+
		"\3\2\2\2\n\u00ac\3\2\2\2\f\u00ae\3\2\2\2\16\u00c2\3\2\2\2\20\u00c4\3\2"+
		"\2\2\22\u00cb\3\2\2\2\24\u00d2\3\2\2\2\26\u00d9\3\2\2\2\30\u00db\3\2\2"+
		"\2\32\u00eb\3\2\2\2\34\u00fe\3\2\2\2\36\u010e\3\2\2\2 \u011c\3\2\2\2\""+
		"\u012c\3\2\2\2$\u012e\3\2\2\2&\u0137\3\2\2\2(\u013b\3\2\2\2*\u0144\3\2"+
		"\2\2,\u0163\3\2\2\2.\u0165\3\2\2\2\60\u016d\3\2\2\2\62\u0181\3\2\2\2\64"+
		"\u0186\3\2\2\2\66\u01a0\3\2\2\28\u01a9\3\2\2\2:\u01b3\3\2\2\2<\u01b5\3"+
		"\2\2\2>\u01b7\3\2\2\2@\u01b9\3\2\2\2B\u01cd\3\2\2\2D\u01cf\3\2\2\2F\u01da"+
		"\3\2\2\2H\u01e8\3\2\2\2J\u01ea\3\2\2\2L\u01f1\3\2\2\2N\u01fb\3\2\2\2P"+
		"\u0205\3\2\2\2R\u0213\3\2\2\2T\u0222\3\2\2\2V\u0224\3\2\2\2X\u0235\3\2"+
		"\2\2Z\u0252\3\2\2\2\\\u0254\3\2\2\2^\u0256\3\2\2\2`\u0258\3\2\2\2b\u025a"+
		"\3\2\2\2d\u028b\3\2\2\2f\u028d\3\2\2\2h\u0292\3\2\2\2j\u02ab\3\2\2\2l"+
		"\u02cd\3\2\2\2n\u02cf\3\2\2\2p\u02d9\3\2\2\2r\u02de\3\2\2\2t\u02e3\3\2"+
		"\2\2v\u02e8\3\2\2\2x\u02ed\3\2\2\2z\u0306\3\2\2\2|\u0334\3\2\2\2~\u036a"+
		"\3\2\2\2\u0080\u036c\3\2\2\2\u0082\u036e\3\2\2\2\u0084\u0374\3\2\2\2\u0086"+
		"\u037b\3\2\2\2\u0088\u008c\5\4\3\2\u0089\u008b\5\6\4\2\u008a\u0089\3\2"+
		"\2\2\u008b\u008e\3\2\2\2\u008c\u008a\3\2\2\2\u008c\u008d\3\2\2\2\u008d"+
		"\u008f\3\2\2\2\u008e\u008c\3\2\2\2\u008f\u0093\5\b\5\2\u0090\u0092\5\20"+
		"\t\2\u0091\u0090\3\2\2\2\u0092\u0095\3\2\2\2\u0093\u0091\3\2\2\2\u0093"+
		"\u0094\3\2\2\2\u0094\u0099\3\2\2\2\u0095\u0093\3\2\2\2\u0096\u0098\5\22"+
		"\n\2\u0097\u0096\3\2\2\2\u0098\u009b\3\2\2\2\u0099\u0097\3\2\2\2\u0099"+
		"\u009a\3\2\2\2\u009a\u009f\3\2\2\2\u009b\u0099\3\2\2\2\u009c\u009e\5\24"+
		"\13\2\u009d\u009c\3\2\2\2\u009e\u00a1\3\2\2\2\u009f\u009d\3\2\2\2\u009f"+
		"\u00a0\3\2\2\2\u00a0\u00a2\3\2\2\2\u00a1\u009f\3\2\2\2\u00a2\u00a3\5\f"+
		"\7\2\u00a3\u00a4\5\n\6\2\u00a4\u00a5\7\2\2\3\u00a5\3\3\2\2\2\u00a6\u00a7"+
		"\7\"\2\2\u00a7\5\3\2\2\2\u00a8\u00a9\t\2\2\2\u00a9\7\3\2\2\2\u00aa\u00ab"+
		"\7-\2\2\u00ab\t\3\2\2\2\u00ac\u00ad\7.\2\2\u00ad\13\3\2\2\2\u00ae\u00af"+
		"\b\7\1\2\u00af\u00b0\5\16\b\2\u00b0\u00b5\3\2\2\2\u00b1\u00b2\f\4\2\2"+
		"\u00b2\u00b4\5\16\b\2\u00b3\u00b1\3\2\2\2\u00b4\u00b7\3\2\2\2\u00b5\u00b3"+
		"\3\2\2\2\u00b5\u00b6\3\2\2\2\u00b6\r\3\2\2\2\u00b7\u00b5\3\2\2\2\u00b8"+
		"\u00c3\5\30\r\2\u00b9\u00c3\5\32\16\2\u00ba\u00c3\5\36\20\2\u00bb\u00c3"+
		"\5v<\2\u00bc\u00c3\5x=\2\u00bd\u00c3\5.\30\2\u00be\u00c3\5\60\31\2\u00bf"+
		"\u00c3\5\26\f\2\u00c0\u00c3\5,\27\2\u00c1\u00c3\5|?\2\u00c2\u00b8\3\2"+
		"\2\2\u00c2\u00b9\3\2\2\2\u00c2\u00ba\3\2\2\2\u00c2\u00bb\3\2\2\2\u00c2"+
		"\u00bc\3\2\2\2\u00c2\u00bd\3\2\2\2\u00c2\u00be\3\2\2\2\u00c2\u00bf\3\2"+
		"\2\2\u00c2\u00c0\3\2\2\2\u00c2\u00c1\3\2\2\2\u00c3\17\3\2\2\2\u00c4\u00c8"+
		"\7\65\2\2\u00c5\u00c7\7U\2\2\u00c6\u00c5\3\2\2\2\u00c7\u00ca\3\2\2\2\u00c8"+
		"\u00c6\3\2\2\2\u00c8\u00c9\3\2\2\2\u00c9\21\3\2\2\2\u00ca\u00c8\3\2\2"+
		"\2\u00cb\u00cf\7\66\2\2\u00cc\u00ce\7U\2\2\u00cd\u00cc\3\2\2\2\u00ce\u00d1"+
		"\3\2\2\2\u00cf\u00cd\3\2\2\2\u00cf\u00d0\3\2\2\2\u00d0\23\3\2\2\2\u00d1"+
		"\u00cf\3\2\2\2\u00d2\u00d6\7\67\2\2\u00d3\u00d5\7U\2\2\u00d4\u00d3\3\2"+
		"\2\2\u00d5\u00d8\3\2\2\2\u00d6\u00d4\3\2\2\2\u00d6\u00d7\3\2\2\2\u00d7"+
		"\25\3\2\2\2\u00d8\u00d6\3\2\2\2\u00d9\u00da\78\2\2\u00da\27\3\2\2\2\u00db"+
		"\u00df\79\2\2\u00dc\u00de\7U\2\2\u00dd\u00dc\3\2\2\2\u00de\u00e1\3\2\2"+
		"\2\u00df\u00dd\3\2\2\2\u00df\u00e0\3\2\2\2\u00e0\u00e2\3\2\2\2\u00e1\u00df"+
		"\3\2\2\2\u00e2\u00e6\5|?\2\u00e3\u00e5\7U\2\2\u00e4\u00e3\3\2\2\2\u00e5"+
		"\u00e8\3\2\2\2\u00e6\u00e4\3\2\2\2\u00e6\u00e7\3\2\2\2\u00e7\u00e9\3\2"+
		"\2\2\u00e8\u00e6\3\2\2\2\u00e9\u00ea\7:\2\2\u00ea\31\3\2\2\2\u00eb\u00ef"+
		"\5\34\17\2\u00ec\u00ee\5|?\2\u00ed\u00ec\3\2\2\2\u00ee\u00f1\3\2\2\2\u00ef"+
		"\u00ed\3\2\2\2\u00ef\u00f0\3\2\2\2\u00f0\u00f5\3\2\2\2\u00f1\u00ef\3\2"+
		"\2\2\u00f2\u00f4\5z>\2\u00f3\u00f2\3\2\2\2\u00f4\u00f7\3\2\2\2\u00f5\u00f3"+
		"\3\2\2\2\u00f5\u00f6\3\2\2\2\u00f6\u00fb\3\2\2\2\u00f7\u00f5\3\2\2\2\u00f8"+
		"\u00fa\5|?\2\u00f9\u00f8\3\2\2\2\u00fa\u00fd\3\2\2\2\u00fb\u00f9\3\2\2"+
		"\2\u00fb\u00fc\3\2\2\2\u00fc\33\3\2\2\2\u00fd\u00fb\3\2\2\2\u00fe\u0102"+
		"\7;\2\2\u00ff\u0101\7\3\2\2\u0100\u00ff\3\2\2\2\u0101\u0104\3\2\2\2\u0102"+
		"\u0100\3\2\2\2\u0102\u0103\3\2\2\2\u0103\u0105\3\2\2\2\u0104\u0102\3\2"+
		"\2\2\u0105\u0106\7\22\2\2\u0106\u0107\5z>\2\u0107\u010b\7\23\2\2\u0108"+
		"\u010a\7U\2\2\u0109\u0108\3\2\2\2\u010a\u010d\3\2\2\2\u010b\u0109\3\2"+
		"\2\2\u010b\u010c\3\2\2\2\u010c\35\3\2\2\2\u010d\u010b\3\2\2\2\u010e\u010f"+
		"\5 \21\2\u010f\u0113\5|?\2\u0110\u0112\5z>\2\u0111\u0110\3\2\2\2\u0112"+
		"\u0115\3\2\2\2\u0113\u0111\3\2\2\2\u0113\u0114\3\2\2\2\u0114\u0119\3\2"+
		"\2\2\u0115\u0113\3\2\2\2\u0116\u0118\5|?\2\u0117\u0116\3\2\2\2\u0118\u011b"+
		"\3\2\2\2\u0119\u0117\3\2\2\2\u0119\u011a\3\2\2\2\u011a\37\3\2\2\2\u011b"+
		"\u0119\3\2\2\2\u011c\u0120\7<\2\2\u011d\u011f\7\3\2\2\u011e\u011d\3\2"+
		"\2\2\u011f\u0122\3\2\2\2\u0120\u011e\3\2\2\2\u0120\u0121\3\2\2\2\u0121"+
		"\u0123\3\2\2\2\u0122\u0120\3\2\2\2\u0123\u0124\7\22\2\2\u0124\u0125\5"+
		"z>\2\u0125\u0129\7\23\2\2\u0126\u0128\7U\2\2\u0127\u0126\3\2\2\2\u0128"+
		"\u012b\3\2\2\2\u0129\u0127\3\2\2\2\u0129\u012a\3\2\2\2\u012a!\3\2\2\2"+
		"\u012b\u0129\3\2\2\2\u012c\u012d\7A\2\2\u012d#\3\2\2\2\u012e\u0132\7\63"+
		"\2\2\u012f\u0131\5|?\2\u0130\u012f\3\2\2\2\u0131\u0134\3\2\2\2\u0132\u0130"+
		"\3\2\2\2\u0132\u0133\3\2\2\2\u0133\u0135\3\2\2\2\u0134\u0132\3\2\2\2\u0135"+
		"\u0136\7\64\2\2\u0136%\3\2\2\2\u0137\u0138\7\24\2\2\u0138\u0139\7Z\2\2"+
		"\u0139\u013a\7\25\2\2\u013a\'\3\2\2\2\u013b\u013c\7\22\2\2\u013c\u013d"+
		"\7O\2\2\u013d\u0141\7\23\2\2\u013e\u0140\7U\2\2\u013f\u013e\3\2\2\2\u0140"+
		"\u0143\3\2\2\2\u0141\u013f\3\2\2\2\u0141\u0142\3\2\2\2\u0142)\3\2\2\2"+
		"\u0143\u0141\3\2\2\2\u0144\u0146\7\61\2\2\u0145\u0147\5&\24\2\u0146\u0145"+
		"\3\2\2\2\u0146\u0147\3\2\2\2\u0147\u0148\3\2\2\2\u0148\u014c\5(\25\2\u0149"+
		"\u014b\t\3\2\2\u014a\u0149\3\2\2\2\u014b\u014e\3\2\2\2\u014c\u014a\3\2"+
		"\2\2\u014c\u014d\3\2\2\2\u014d+\3\2\2\2\u014e\u014c\3\2\2\2\u014f\u0150"+
		"\7/\2\2\u0150\u0152\5*\26\2\u0151\u0153\5v<\2\u0152\u0151\3\2\2\2\u0152"+
		"\u0153\3\2\2\2\u0153\u0155\3\2\2\2\u0154\u0156\5t;\2\u0155\u0154\3\2\2"+
		"\2\u0155\u0156\3\2\2\2\u0156\u0158\3\2\2\2\u0157\u0159\5v<\2\u0158\u0157"+
		"\3\2\2\2\u0158\u0159\3\2\2\2\u0159\u015a\3\2\2\2\u015a\u015b\7\60\2\2"+
		"\u015b\u0164\3\2\2\2\u015c\u015e\7/\2\2\u015d\u015f\5t;\2\u015e\u015d"+
		"\3\2\2\2\u015e\u015f\3\2\2\2\u015f\u0160\3\2\2\2\u0160\u0161\5*\26\2\u0161"+
		"\u0162\7\60\2\2\u0162\u0164\3\2\2\2\u0163\u014f\3\2\2\2\u0163\u015c\3"+
		"\2\2\2\u0164-\3\2\2\2\u0165\u0167\7D\2\2\u0166\u0168\5\62\32\2\u0167\u0166"+
		"\3\2\2\2\u0168\u0169\3\2\2\2\u0169\u0167\3\2\2\2\u0169\u016a\3\2\2\2\u016a"+
		"\u016b\3\2\2\2\u016b\u016c\7F\2\2\u016c/\3\2\2\2\u016d\u016f\7G\2\2\u016e"+
		"\u0170\5\62\32\2\u016f\u016e\3\2\2\2\u0170\u0171\3\2\2\2\u0171\u016f\3"+
		"\2\2\2\u0171\u0172\3\2\2\2\u0172\u0173\3\2\2\2\u0173\u0174\7H\2\2\u0174"+
		"\61\3\2\2\2\u0175\u0176\7E\2\2\u0176\u0178\5\64\33\2\u0177\u0175\3\2\2"+
		"\2\u0178\u0179\3\2\2\2\u0179\u0177\3\2\2\2\u0179\u017a\3\2\2\2\u017a\u0182"+
		"\3\2\2\2\u017b\u017c\5.\30\2\u017c\u017d\5\62\32\2\u017d\u0182\3\2\2\2"+
		"\u017e\u017f\5\60\31\2\u017f\u0180\5\62\32\2\u0180\u0182\3\2\2\2\u0181"+
		"\u0177\3\2\2\2\u0181\u017b\3\2\2\2\u0181\u017e\3\2\2\2\u0182\63\3\2\2"+
		"\2\u0183\u0185\7\3\2\2\u0184\u0183\3\2\2\2\u0185\u0188\3\2\2\2\u0186\u0184"+
		"\3\2\2\2\u0186\u0187\3\2\2\2\u0187\u018c\3\2\2\2\u0188\u0186\3\2\2\2\u0189"+
		"\u018b\5z>\2\u018a\u0189\3\2\2\2\u018b\u018e\3\2\2\2\u018c\u018a\3\2\2"+
		"\2\u018c\u018d\3\2\2\2\u018d\u0192\3\2\2\2\u018e\u018c\3\2\2\2\u018f\u0191"+
		"\7U\2\2\u0190\u018f\3\2\2\2\u0191\u0194\3\2\2\2\u0192\u0190\3\2\2\2\u0192"+
		"\u0193\3\2\2\2\u0193\65\3\2\2\2\u0194\u0192\3\2\2\2\u0195\u0197\58\35"+
		"\2\u0196\u0198\7U\2\2\u0197\u0196\3\2\2\2\u0197\u0198\3\2\2\2\u0198\u01a1"+
		"\3\2\2\2\u0199\u019a\7\t\2\2\u019a\u019b\7\30\2\2\u019b\u019d\58\35\2"+
		"\u019c\u019e\7U\2\2\u019d\u019c\3\2\2\2\u019d\u019e\3\2\2\2\u019e\u01a1"+
		"\3\2\2\2\u019f\u01a1\7U\2\2\u01a0\u0195\3\2\2\2\u01a0\u0199\3\2\2\2\u01a0"+
		"\u019f\3\2\2\2\u01a1\67\3\2\2\2\u01a2\u01a3\b\35\1\2\u01a3\u01aa\7W\2"+
		"\2\u01a4\u01aa\7\t\2\2\u01a5\u01a6\7\26\2\2\u01a6\u01a7\58\35\2\u01a7"+
		"\u01a8\7\27\2\2\u01a8\u01aa\3\2\2\2\u01a9\u01a2\3\2\2\2\u01a9\u01a4\3"+
		"\2\2\2\u01a9\u01a5\3\2\2\2\u01aa\u01b0\3\2\2\2\u01ab\u01ac\f\6\2\2\u01ac"+
		"\u01ad\t\4\2\2\u01ad\u01af\58\35\7\u01ae\u01ab\3\2\2\2\u01af\u01b2\3\2"+
		"\2\2\u01b0\u01ae\3\2\2\2\u01b0\u01b1\3\2\2\2\u01b19\3\2\2\2\u01b2\u01b0"+
		"\3\2\2\2\u01b3\u01b4\7S\2\2\u01b4;\3\2\2\2\u01b5\u01b6\7 \2\2\u01b6=\3"+
		"\2\2\2\u01b7\u01b8\7!\2\2\u01b8?\3\2\2\2\u01b9\u01ba\7\16\2\2\u01ba\u01be"+
		"\5R*\2\u01bb\u01bd\7U\2\2\u01bc\u01bb\3\2\2\2\u01bd\u01c0\3\2\2\2\u01be"+
		"\u01bc\3\2\2\2\u01be\u01bf\3\2\2\2\u01bfA\3\2\2\2\u01c0\u01be\3\2\2\2"+
		"\u01c1\u01c2\7\17\2\2\u01c2\u01c6\5P)\2\u01c3\u01c5\7U\2\2\u01c4\u01c3"+
		"\3\2\2\2\u01c5\u01c8\3\2\2\2\u01c6\u01c4\3\2\2\2\u01c6\u01c7\3\2\2\2\u01c7"+
		"\u01ce\3\2\2\2\u01c8\u01c6\3\2\2\2\u01c9\u01ca\7\17\2\2\u01ca\u01ce\5"+
		"@!\2\u01cb\u01cc\7\17\2\2\u01cc\u01ce\5H%\2\u01cd\u01c1\3\2\2\2\u01cd"+
		"\u01c9\3\2\2\2\u01cd\u01cb\3\2\2\2\u01ceC\3\2\2\2\u01cf\u01d0\7\20\2\2"+
		"\u01d0\u01d1\7\34\2\2\u01d1\u01d2\5L\'\2\u01d2\u01d3\7\33\2\2\u01d3\u01d7"+
		"\5N(\2\u01d4\u01d6\7U\2\2\u01d5\u01d4\3\2\2\2\u01d6\u01d9\3\2\2\2\u01d7"+
		"\u01d5\3\2\2\2\u01d7\u01d8\3\2\2\2\u01d8E\3\2\2\2\u01d9\u01d7\3\2\2\2"+
		"\u01da\u01db\7\21\2\2\u01dbG\3\2\2\2\u01dc\u01dd\5F$\2\u01dd\u01de\7\34"+
		"\2\2\u01de\u01df\5L\'\2\u01df\u01e0\7\33\2\2\u01e0\u01e4\5N(\2\u01e1\u01e3"+
		"\7U\2\2\u01e2\u01e1\3\2\2\2\u01e3\u01e6\3\2\2\2\u01e4\u01e2\3\2\2\2\u01e4"+
		"\u01e5\3\2\2\2\u01e5\u01e9\3\2\2\2\u01e6\u01e4\3\2\2\2\u01e7\u01e9\5F"+
		"$\2\u01e8\u01dc\3\2\2\2\u01e8\u01e7\3\2\2\2\u01e9I\3\2\2\2\u01ea\u01ee"+
		"\5H%\2\u01eb\u01ed\58\35\2\u01ec\u01eb\3\2\2\2\u01ed\u01f0\3\2\2\2\u01ee"+
		"\u01ec\3\2\2\2\u01ee\u01ef\3\2\2\2\u01efK\3\2\2\2\u01f0\u01ee\3\2\2\2"+
		"\u01f1\u01f2\7\22\2\2\u01f2\u01f4\t\5\2\2\u01f3\u01f5\7\30\2\2\u01f4\u01f3"+
		"\3\2\2\2\u01f4\u01f5\3\2\2\2\u01f5\u01f7\3\2\2\2\u01f6\u01f8\t\5\2\2\u01f7"+
		"\u01f6\3\2\2\2\u01f7\u01f8\3\2\2\2\u01f8\u01f9\3\2\2\2\u01f9\u01fa\7\23"+
		"\2\2\u01faM\3\2\2\2\u01fb\u01fc\7\22\2\2\u01fc\u01fe\t\5\2\2\u01fd\u01ff"+
		"\7\30\2\2\u01fe\u01fd\3\2\2\2\u01fe\u01ff\3\2\2\2\u01ff\u0201\3\2\2\2"+
		"\u0200\u0202\t\5\2\2\u0201\u0200\3\2\2\2\u0201\u0202\3\2\2\2\u0202\u0203"+
		"\3\2\2\2\u0203\u0204\7\23\2\2\u0204O\3\2\2\2\u0205\u020f\7\22\2\2\u0206"+
		"\u0210\7\30\2\2\u0207\u0210\7\t\2\2\u0208\u0210\7O\2\2\u0209\u0210\7Y"+
		"\2\2\u020a\u0210\7\3\2\2\u020b\u0210\7X\2\2\u020c\u0210\5B\"\2\u020d\u0210"+
		"\5D#\2\u020e\u0210\5H%\2\u020f\u0206\3\2\2\2\u020f\u0207\3\2\2\2\u020f"+
		"\u0208\3\2\2\2\u020f\u0209\3\2\2\2\u020f\u020a\3\2\2\2\u020f\u020b\3\2"+
		"\2\2\u020f\u020c\3\2\2\2\u020f\u020d\3\2\2\2\u020f\u020e\3\2\2\2\u0210"+
		"\u0211\3\2\2\2\u0211\u0212\7\23\2\2\u0212Q\3\2\2\2\u0213\u0214\5T+\2\u0214"+
		"\u0215\5T+\2\u0215S\3\2\2\2\u0216\u0217\7\22\2\2\u0217\u0218\5z>\2\u0218"+
		"\u0219\7\23\2\2\u0219\u0223\3\2\2\2\u021a\u021e\7\22\2\2\u021b\u021f\5"+
		"B\"\2\u021c\u021f\5D#\2\u021d\u021f\5H%\2\u021e\u021b\3\2\2\2\u021e\u021c"+
		"\3\2\2\2\u021e\u021d\3\2\2\2\u021f\u0220\3\2\2\2\u0220\u0221\7\23\2\2"+
		"\u0221\u0223\3\2\2\2\u0222\u0216\3\2\2\2\u0222\u021a\3\2\2\2\u0223U\3"+
		"\2\2\2\u0224\u022f\7\37\2\2\u0225\u0230\5z>\2\u0226\u0230\5<\37\2\u0227"+
		"\u0230\5J&\2\u0228\u0230\5> \2\u0229\u0230\5D#\2\u022a\u0230\5@!\2\u022b"+
		"\u022c\5B\"\2\u022c\u022d\7\3\2\2\u022d\u0230\3\2\2\2\u022e\u0230\5:\36"+
		"\2\u022f\u0225\3\2\2\2\u022f\u0226\3\2\2\2\u022f\u0227\3\2\2\2\u022f\u0228"+
		"\3\2\2\2\u022f\u0229\3\2\2\2\u022f\u022a\3\2\2\2\u022f\u022b\3\2\2\2\u022f"+
		"\u022e\3\2\2\2\u0230\u0231\3\2\2\2\u0231\u022f\3\2\2\2\u0231\u0232\3\2"+
		"\2\2\u0232\u0233\3\2\2\2\u0233\u0234\7\37\2\2\u0234W\3\2\2\2\u0235\u024c"+
		"\7\36\2\2\u0236\u024d\5<\37\2\u0237\u024d\5> \2\u0238\u024d\5D#\2\u0239"+
		"\u024d\5@!\2\u023a\u024d\5B\"\2\u023b\u024d\5J&\2\u023c\u023e\5z>\2\u023d"+
		"\u023c\3\2\2\2\u023e\u023f\3\2\2\2\u023f\u023d\3\2\2\2\u023f\u0240\3\2"+
		"\2\2\u0240\u024d\3\2\2\2\u0241\u024d\7\22\2\2\u0242\u024d\7\23\2\2\u0243"+
		"\u024d\7\26\2\2\u0244\u024d\7\27\2\2\u0245\u024d\5<\37\2\u0246\u024d\5"+
		"> \2\u0247\u024d\5D#\2\u0248\u024d\5@!\2\u0249\u024d\5B\"\2\u024a\u024d"+
		"\7\3\2\2\u024b\u024d\5:\36\2\u024c\u0236\3\2\2\2\u024c\u0237\3\2\2\2\u024c"+
		"\u0238\3\2\2\2\u024c\u0239\3\2\2\2\u024c\u023a\3\2\2\2\u024c\u023b\3\2"+
		"\2\2\u024c\u023d\3\2\2\2\u024c\u0241\3\2\2\2\u024c\u0242\3\2\2\2\u024c"+
		"\u0243\3\2\2\2\u024c\u0244\3\2\2\2\u024c\u0245\3\2\2\2\u024c\u0246\3\2"+
		"\2\2\u024c\u0247\3\2\2\2\u024c\u0248\3\2\2\2\u024c\u0249\3\2\2\2\u024c"+
		"\u024a\3\2\2\2\u024c\u024b\3\2\2\2\u024d\u024e\3\2\2\2\u024e\u024c\3\2"+
		"\2\2\u024e\u024f\3\2\2\2\u024f\u0250\3\2\2\2\u0250\u0251\7\36\2\2\u0251"+
		"Y\3\2\2\2\u0252\u0253\7I\2\2\u0253[\3\2\2\2\u0254\u0255\7J\2\2\u0255]"+
		"\3\2\2\2\u0256\u0257\7K\2\2\u0257_\3\2\2\2\u0258\u0259\7L\2\2\u0259a\3"+
		"\2\2\2\u025a\u025b\7M\2\2\u025bc\3\2\2\2\u025c\u025e\7\3\2\2\u025d\u025c"+
		"\3\2\2\2\u025e\u0261\3\2\2\2\u025f\u025d\3\2\2\2\u025f\u0260\3\2\2\2\u0260"+
		"\u0268\3\2\2\2\u0261\u025f\3\2\2\2\u0262\u0264\5h\65\2\u0263\u0265\7\3"+
		"\2\2\u0264\u0263\3\2\2\2\u0265\u0266\3\2\2\2\u0266\u0264\3\2\2\2\u0266"+
		"\u0267\3\2\2\2\u0267\u0269\3\2\2\2\u0268\u0262\3\2\2\2\u0269\u026a\3\2"+
		"\2\2\u026a\u0268\3\2\2\2\u026a\u026b\3\2\2\2\u026b\u026d\3\2\2\2\u026c"+
		"\u026e\7\3\2\2\u026d\u026c\3\2\2\2\u026e\u026f\3\2\2\2\u026f\u026d\3\2"+
		"\2\2\u026f\u0270\3\2\2\2\u0270\u0272\3\2\2\2\u0271\u025f\3\2\2\2\u0272"+
		"\u0273\3\2\2\2\u0273\u0271\3\2\2\2\u0273\u0274\3\2\2\2\u0274\u0278\3\2"+
		"\2\2\u0275\u0277\7\6\2\2\u0276\u0275\3\2\2\2\u0277\u027a\3\2\2\2\u0278"+
		"\u0276\3\2\2\2\u0278\u0279\3\2\2\2\u0279\u027e\3\2\2\2\u027a\u0278\3\2"+
		"\2\2\u027b\u027d\7\3\2\2\u027c\u027b\3\2\2\2\u027d\u0280\3\2\2\2\u027e"+
		"\u027c\3\2\2\2\u027e\u027f\3\2\2\2\u027f\u0282\3\2\2\2\u0280\u027e\3\2"+
		"\2\2\u0281\u0283\5f\64\2\u0282\u0281\3\2\2\2\u0282\u0283\3\2\2\2\u0283"+
		"\u028c\3\2\2\2\u0284\u0288\7\n\2\2\u0285\u0287\7\3\2\2\u0286\u0285\3\2"+
		"\2\2\u0287\u028a\3\2\2\2\u0288\u0286\3\2\2\2\u0288\u0289\3\2\2\2\u0289"+
		"\u028c\3\2\2\2\u028a\u0288\3\2\2\2\u028b\u0271\3\2\2\2\u028b\u0284\3\2"+
		"\2\2\u028ce\3\2\2\2\u028d\u028e\7\n\2\2\u028eg\3\2\2\2\u028f\u0291\t\6"+
		"\2\2\u0290\u028f\3\2\2\2\u0291\u0294\3\2\2\2\u0292\u0290\3\2\2\2\u0292"+
		"\u0293\3\2\2\2\u0293\u0298\3\2\2\2\u0294\u0292\3\2\2\2\u0295\u0297\5z"+
		">\2\u0296\u0295\3\2\2\2\u0297\u029a\3\2\2\2\u0298\u0296\3\2\2\2\u0298"+
		"\u0299\3\2\2\2\u0299\u029e\3\2\2\2\u029a\u0298\3\2\2\2\u029b\u029d\t\6"+
		"\2\2\u029c\u029b\3\2\2\2\u029d\u02a0\3\2\2\2\u029e\u029c\3\2\2\2\u029e"+
		"\u029f\3\2\2\2\u029f\u02a2\3\2\2\2\u02a0\u029e\3\2\2\2\u02a1\u02a3\7\35"+
		"\2\2\u02a2\u02a1\3\2\2\2\u02a2\u02a3\3\2\2\2\u02a3\u02a7\3\2\2\2\u02a4"+
		"\u02a6\t\6\2\2\u02a5\u02a4\3\2\2\2\u02a6\u02a9\3\2\2\2\u02a7\u02a5\3\2"+
		"\2\2\u02a7\u02a8\3\2\2\2\u02a8i\3\2\2\2\u02a9\u02a7\3\2\2\2\u02aa\u02ac"+
		"\5Z.\2\u02ab\u02aa\3\2\2\2\u02ab\u02ac\3\2\2\2\u02ac\u02ad\3\2\2\2\u02ad"+
		"\u02af\5^\60\2\u02ae\u02b0\5b\62\2\u02af\u02ae\3\2\2\2\u02af\u02b0\3\2"+
		"\2\2\u02b0\u02bb\3\2\2\2\u02b1\u02b5\5d\63\2\u02b2\u02b4\7\3\2\2\u02b3"+
		"\u02b2\3\2\2\2\u02b4\u02b7\3\2\2\2\u02b5\u02b3\3\2\2\2\u02b5\u02b6\3\2"+
		"\2\2\u02b6\u02b9\3\2\2\2\u02b7\u02b5\3\2\2\2\u02b8\u02ba\5f\64\2\u02b9"+
		"\u02b8\3\2\2\2\u02b9\u02ba\3\2\2\2\u02ba\u02bc\3\2\2\2\u02bb\u02b1\3\2"+
		"\2\2\u02bc\u02bd\3\2\2\2\u02bd\u02bb\3\2\2\2\u02bd\u02be\3\2\2\2\u02be"+
		"\u02bf\3\2\2\2\u02bf\u02c1\5`\61\2\u02c0\u02c2\5\\/\2\u02c1\u02c0\3\2"+
		"\2\2\u02c1\u02c2\3\2\2\2\u02c2k\3\2\2\2\u02c3\u02ce\7\n\2\2\u02c4\u02ce"+
		"\7\13\2\2\u02c5\u02c9\7\f\2\2\u02c6\u02c8\7\3\2\2\u02c7\u02c6\3\2\2\2"+
		"\u02c8\u02cb\3\2\2\2\u02c9\u02c7\3\2\2\2\u02c9\u02ca\3\2\2\2\u02ca\u02cc"+
		"\3\2\2\2\u02cb\u02c9\3\2\2\2\u02cc\u02ce\7\r\2\2\u02cd\u02c3\3\2\2\2\u02cd"+
		"\u02c4\3\2\2\2\u02cd\u02c5\3\2\2\2\u02cem\3\2\2\2\u02cf\u02d0\7>\2\2\u02d0"+
		"\u02d1\7\22\2\2\u02d1\u02d2\5z>\2\u02d2\u02d6\7\23\2\2\u02d3\u02d5\7\3"+
		"\2\2\u02d4\u02d3\3\2\2\2\u02d5\u02d8\3\2\2\2\u02d6\u02d4\3\2\2\2\u02d6"+
		"\u02d7\3\2\2\2\u02d7o\3\2\2\2\u02d8\u02d6\3\2\2\2\u02d9\u02da\7?\2\2\u02da"+
		"\u02db\7\22\2\2\u02db\u02dc\5z>\2\u02dc\u02dd\7\23\2\2\u02ddq\3\2\2\2"+
		"\u02de\u02df\7@\2\2\u02df\u02e0\7\22\2\2\u02e0\u02e1\5z>\2\u02e1\u02e2"+
		"\7\23\2\2\u02e2s\3\2\2\2\u02e3\u02e4\7\62\2\2\u02e4\u02e5\7\22\2\2\u02e5"+
		"\u02e6\58\35\2\u02e6\u02e7\7\23\2\2\u02e7u\3\2\2\2\u02e8\u02e9\7B\2\2"+
		"\u02e9\u02ea\7\22\2\2\u02ea\u02eb\5z>\2\u02eb\u02ec\7\23\2\2\u02ecw\3"+
		"\2\2\2\u02ed\u02ee\7C\2\2\u02ee\u02ef\7\22\2\2\u02ef\u02f0\5z>\2\u02f0"+
		"\u02f1\7\23\2\2\u02f1y\3\2\2\2\u02f2\u02f4\7U\2\2\u02f3\u02f2\3\2\2\2"+
		"\u02f4\u02f7\3\2\2\2\u02f5\u02f3\3\2\2\2\u02f5\u02f6\3\2\2\2\u02f6\u02f8"+
		"\3\2\2\2\u02f7\u02f5\3\2\2\2\u02f8\u0307\7Z\2\2\u02f9\u0307\7O\2\2\u02fa"+
		"\u0307\7W\2\2\u02fb\u0307\7Y\2\2\u02fc\u0307\7\5\2\2\u02fd\u0307\7\3\2"+
		"\2\u02fe\u0307\7X\2\2\u02ff\u0307\7\30\2\2\u0300\u0307\7\31\2\2\u0301"+
		"\u0307\7\32\2\2\u0302\u0307\7\30\2\2\u0303\u0307\5\66\34\2\u0304\u0307"+
		"\7\26\2\2\u0305\u0307\7\27\2\2\u0306\u02f5\3\2\2\2\u0306\u02f9\3\2\2\2"+
		"\u0306\u02fa\3\2\2\2\u0306\u02fb\3\2\2\2\u0306\u02fc\3\2\2\2\u0306\u02fd"+
		"\3\2\2\2\u0306\u02fe\3\2\2\2\u0306\u02ff\3\2\2\2\u0306\u0300\3\2\2\2\u0306"+
		"\u0301\3\2\2\2\u0306\u0302\3\2\2\2\u0306\u0303\3\2\2\2\u0306\u0304\3\2"+
		"\2\2\u0306\u0305\3\2\2\2\u0307{\3\2\2\2\u0308\u0309\b?\1\2\u0309\u030a"+
		"\5z>\2\u030a\u030b\5r:\2\u030b\u0335\3\2\2\2\u030c\u030d\5z>\2\u030d\u030e"+
		"\5n8\2\u030e\u0335\3\2\2\2\u030f\u0310\5z>\2\u0310\u0311\5p9\2\u0311\u0335"+
		"\3\2\2\2\u0312\u0335\5V,\2\u0313\u0335\5X-\2\u0314\u0335\5j\66\2\u0315"+
		"\u0335\5n8\2\u0316\u0335\5p9\2\u0317\u0335\5r:\2\u0318\u0335\5t;\2\u0319"+
		"\u0335\5@!\2\u031a\u0335\5B\"\2\u031b\u0335\5D#\2\u031c\u0335\5J&\2\u031d"+
		"\u0335\5v<\2\u031e\u0335\5x=\2\u031f\u0335\5\"\22\2\u0320\u0335\5$\23"+
		"\2\u0321\u0323\5l\67\2\u0322\u0321\3\2\2\2\u0323\u0326\3\2\2\2\u0324\u0322"+
		"\3\2\2\2\u0324\u0325\3\2\2\2\u0325\u0327\3\2\2\2\u0326\u0324\3\2\2\2\u0327"+
		"\u032b\5z>\2\u0328\u032a\5l\67\2\u0329\u0328\3\2\2\2\u032a\u032d\3\2\2"+
		"\2\u032b\u0329\3\2\2\2\u032b\u032c\3\2\2\2\u032c\u0331\3\2\2\2\u032d\u032b"+
		"\3\2\2\2\u032e\u0330\5z>\2\u032f\u032e\3\2\2\2\u0330\u0333\3\2\2\2\u0331"+
		"\u032f\3\2\2\2\u0331\u0332\3\2\2\2\u0332\u0335\3\2\2\2\u0333\u0331\3\2"+
		"\2\2\u0334\u0308\3\2\2\2\u0334\u030c\3\2\2\2\u0334\u030f\3\2\2\2\u0334"+
		"\u0312\3\2\2\2\u0334\u0313\3\2\2\2\u0334\u0314\3\2\2\2\u0334\u0315\3\2"+
		"\2\2\u0334\u0316\3\2\2\2\u0334\u0317\3\2\2\2\u0334\u0318\3\2\2\2\u0334"+
		"\u0319\3\2\2\2\u0334\u031a\3\2\2\2\u0334\u031b\3\2\2\2\u0334\u031c\3\2"+
		"\2\2\u0334\u031d\3\2\2\2\u0334\u031e\3\2\2\2\u0334\u031f\3\2\2\2\u0334"+
		"\u0320\3\2\2\2\u0334\u0324\3\2\2\2\u0335\u0367\3\2\2\2\u0336\u033a\f%"+
		"\2\2\u0337\u0339\7\3\2\2\u0338\u0337\3\2\2\2\u0339\u033c\3\2\2\2\u033a"+
		"\u0338\3\2\2\2\u033a\u033b\3\2\2\2\u033b\u033d\3\2\2\2\u033c\u033a\3\2"+
		"\2\2\u033d\u0366\5z>\2\u033e\u033f\f$\2\2\u033f\u0341\5n8\2\u0340\u0342"+
		"\5z>\2\u0341\u0340\3\2\2\2\u0341\u0342\3\2\2\2\u0342\u0366\3\2\2\2\u0343"+
		"\u0344\f#\2\2\u0344\u0346\5p9\2\u0345\u0347\5z>\2\u0346\u0345\3\2\2\2"+
		"\u0346\u0347\3\2\2\2\u0347\u0366\3\2\2\2\u0348\u0349\f\"\2\2\u0349\u034b"+
		"\5r:\2\u034a\u034c\5z>\2\u034b\u034a\3\2\2\2\u034b\u034c\3\2\2\2\u034c"+
		"\u0366\3\2\2\2\u034d\u034e\f!\2\2\u034e\u0366\5t;\2\u034f\u0350\f \2\2"+
		"\u0350\u0366\5@!\2\u0351\u0352\f\37\2\2\u0352\u0366\5B\"\2\u0353\u0354"+
		"\f\36\2\2\u0354\u0366\5D#\2\u0355\u0356\f\35\2\2\u0356\u0366\5J&\2\u0357"+
		"\u0358\f\34\2\2\u0358\u0366\5V,\2\u0359\u035a\f\33\2\2\u035a\u0366\5X"+
		"-\2\u035b\u035c\f\32\2\2\u035c\u0366\5j\66\2\u035d\u035e\f\31\2\2\u035e"+
		"\u0366\5v<\2\u035f\u0360\f\30\2\2\u0360\u0366\5x=\2\u0361\u0362\f\27\2"+
		"\2\u0362\u0366\5$\23\2\u0363\u0364\f\26\2\2\u0364\u0366\5\"\22\2\u0365"+
		"\u0336\3\2\2\2\u0365\u033e\3\2\2\2\u0365\u0343\3\2\2\2\u0365\u0348\3\2"+
		"\2\2\u0365\u034d\3\2\2\2\u0365\u034f\3\2\2\2\u0365\u0351\3\2\2\2\u0365"+
		"\u0353\3\2\2\2\u0365\u0355\3\2\2\2\u0365\u0357\3\2\2\2\u0365\u0359\3\2"+
		"\2\2\u0365\u035b\3\2\2\2\u0365\u035d\3\2\2\2\u0365\u035f\3\2\2\2\u0365"+
		"\u0361\3\2\2\2\u0365\u0363\3\2\2\2\u0366\u0369\3\2\2\2\u0367\u0365\3\2"+
		"\2\2\u0367\u0368\3\2\2\2\u0368}\3\2\2\2\u0369\u0367\3\2\2\2\u036a\u036b"+
		"\7O\2\2\u036b\177\3\2\2\2\u036c\u036d\7Y\2\2\u036d\u0081\3\2\2\2\u036e"+
		"\u036f\7W\2\2\u036f\u0083\3\2\2\2\u0370\u0375\5~@\2\u0371\u0375\5\u0080"+
		"A\2\u0372\u0375\5\u0082B\2\u0373\u0375\7\3\2\2\u0374\u0370\3\2\2\2\u0374"+
		"\u0371\3\2\2\2\u0374\u0372\3\2\2\2\u0374\u0373\3\2\2\2\u0375\u0376\3\2"+
		"\2\2\u0376\u0374\3\2\2\2\u0376\u0377\3\2\2\2\u0377\u0085\3\2\2\2\u0378"+
		"\u037a\t\6\2\2\u0379\u0378\3\2\2\2\u037a\u037d\3\2\2\2\u037b\u0379\3\2"+
		"\2\2\u037b\u037c\3\2\2\2\u037c\u0387\3\2\2\2\u037d\u037b\3\2\2\2\u037e"+
		"\u0382\7O\2\2\u037f\u0381\t\6\2\2\u0380\u037f\3\2\2\2\u0381\u0384\3\2"+
		"\2\2\u0382\u0380\3\2\2\2\u0382\u0383\3\2\2\2\u0383\u0386\3\2\2\2\u0384"+
		"\u0382\3\2\2\2\u0385\u037e\3\2\2\2\u0386\u0389\3\2\2\2\u0387\u0385\3\2"+
		"\2\2\u0387\u0388\3\2\2\2\u0388\u038a\3\2\2\2\u0389\u0387\3\2\2\2\u038a"+
		"\u038b\t\7\2\2\u038b\u0087\3\2\2\2g\u008c\u0093\u0099\u009f\u00b5\u00c2"+
		"\u00c8\u00cf\u00d6\u00df\u00e6\u00ef\u00f5\u00fb\u0102\u010b\u0113\u0119"+
		"\u0120\u0129\u0132\u0141\u0146\u014c\u0152\u0155\u0158\u015e\u0163\u0169"+
		"\u0171\u0179\u0181\u0186\u018c\u0192\u0197\u019d\u01a0\u01a9\u01b0\u01be"+
		"\u01c6\u01cd\u01d7\u01e4\u01e8\u01ee\u01f4\u01f7\u01fe\u0201\u020f\u021e"+
		"\u0222\u022f\u0231\u023f\u024c\u024e\u025f\u0266\u026a\u026f\u0273\u0278"+
		"\u027e\u0282\u0288\u028b\u0292\u0298\u029e\u02a2\u02a7\u02ab\u02af\u02b5"+
		"\u02b9\u02bd\u02c1\u02c9\u02cd\u02d6\u02f5\u0306\u0324\u032b\u0331\u0334"+
		"\u033a\u0341\u0346\u034b\u0365\u0367\u0374\u0376\u037b\u0382\u0387";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}