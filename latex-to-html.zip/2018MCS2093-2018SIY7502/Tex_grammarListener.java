// Generated from Tex_grammar.g4 by ANTLR 4.5
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link Tex_grammarParser}.
 */
public interface Tex_grammarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#root}.
	 * @param ctx the parse tree
	 */
	void enterRoot(Tex_grammarParser.RootContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#root}.
	 * @param ctx the parse tree
	 */
	void exitRoot(Tex_grammarParser.RootContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#docclass}.
	 * @param ctx the parse tree
	 */
	void enterDocclass(Tex_grammarParser.DocclassContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#docclass}.
	 * @param ctx the parse tree
	 */
	void exitDocclass(Tex_grammarParser.DocclassContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#preamble}.
	 * @param ctx the parse tree
	 */
	void enterPreamble(Tex_grammarParser.PreambleContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#preamble}.
	 * @param ctx the parse tree
	 */
	void exitPreamble(Tex_grammarParser.PreambleContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#begindocument}.
	 * @param ctx the parse tree
	 */
	void enterBegindocument(Tex_grammarParser.BegindocumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#begindocument}.
	 * @param ctx the parse tree
	 */
	void exitBegindocument(Tex_grammarParser.BegindocumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#enddocument}.
	 * @param ctx the parse tree
	 */
	void enterEnddocument(Tex_grammarParser.EnddocumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#enddocument}.
	 * @param ctx the parse tree
	 */
	void exitEnddocument(Tex_grammarParser.EnddocumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#body_text}.
	 * @param ctx the parse tree
	 */
	void enterBody_text(Tex_grammarParser.Body_textContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#body_text}.
	 * @param ctx the parse tree
	 */
	void exitBody_text(Tex_grammarParser.Body_textContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#body_parts}.
	 * @param ctx the parse tree
	 */
	void enterBody_parts(Tex_grammarParser.Body_partsContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#body_parts}.
	 * @param ctx the parse tree
	 */
	void exitBody_parts(Tex_grammarParser.Body_partsContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#title}.
	 * @param ctx the parse tree
	 */
	void enterTitle(Tex_grammarParser.TitleContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#title}.
	 * @param ctx the parse tree
	 */
	void exitTitle(Tex_grammarParser.TitleContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#author}.
	 * @param ctx the parse tree
	 */
	void enterAuthor(Tex_grammarParser.AuthorContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#author}.
	 * @param ctx the parse tree
	 */
	void exitAuthor(Tex_grammarParser.AuthorContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#date}.
	 * @param ctx the parse tree
	 */
	void enterDate(Tex_grammarParser.DateContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#date}.
	 * @param ctx the parse tree
	 */
	void exitDate(Tex_grammarParser.DateContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#maketitle}.
	 * @param ctx the parse tree
	 */
	void enterMaketitle(Tex_grammarParser.MaketitleContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#maketitle}.
	 * @param ctx the parse tree
	 */
	void exitMaketitle(Tex_grammarParser.MaketitleContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#optionalAbstract}.
	 * @param ctx the parse tree
	 */
	void enterOptionalAbstract(Tex_grammarParser.OptionalAbstractContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#optionalAbstract}.
	 * @param ctx the parse tree
	 */
	void exitOptionalAbstract(Tex_grammarParser.OptionalAbstractContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#section}.
	 * @param ctx the parse tree
	 */
	void enterSection(Tex_grammarParser.SectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#section}.
	 * @param ctx the parse tree
	 */
	void exitSection(Tex_grammarParser.SectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#sectionName}.
	 * @param ctx the parse tree
	 */
	void enterSectionName(Tex_grammarParser.SectionNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#sectionName}.
	 * @param ctx the parse tree
	 */
	void exitSectionName(Tex_grammarParser.SectionNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#subsection}.
	 * @param ctx the parse tree
	 */
	void enterSubsection(Tex_grammarParser.SubsectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#subsection}.
	 * @param ctx the parse tree
	 */
	void exitSubsection(Tex_grammarParser.SubsectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#subsectionName}.
	 * @param ctx the parse tree
	 */
	void enterSubsectionName(Tex_grammarParser.SubsectionNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#subsectionName}.
	 * @param ctx the parse tree
	 */
	void exitSubsectionName(Tex_grammarParser.SubsectionNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#par}.
	 * @param ctx the parse tree
	 */
	void enterPar(Tex_grammarParser.ParContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#par}.
	 * @param ctx the parse tree
	 */
	void exitPar(Tex_grammarParser.ParContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#center}.
	 * @param ctx the parse tree
	 */
	void enterCenter(Tex_grammarParser.CenterContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#center}.
	 * @param ctx the parse tree
	 */
	void exitCenter(Tex_grammarParser.CenterContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#graphicsHW}.
	 * @param ctx the parse tree
	 */
	void enterGraphicsHW(Tex_grammarParser.GraphicsHWContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#graphicsHW}.
	 * @param ctx the parse tree
	 */
	void exitGraphicsHW(Tex_grammarParser.GraphicsHWContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#graphicsName}.
	 * @param ctx the parse tree
	 */
	void enterGraphicsName(Tex_grammarParser.GraphicsNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#graphicsName}.
	 * @param ctx the parse tree
	 */
	void exitGraphicsName(Tex_grammarParser.GraphicsNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#graphics}.
	 * @param ctx the parse tree
	 */
	void enterGraphics(Tex_grammarParser.GraphicsContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#graphics}.
	 * @param ctx the parse tree
	 */
	void exitGraphics(Tex_grammarParser.GraphicsContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#figure}.
	 * @param ctx the parse tree
	 */
	void enterFigure(Tex_grammarParser.FigureContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#figure}.
	 * @param ctx the parse tree
	 */
	void exitFigure(Tex_grammarParser.FigureContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#ordered_list}.
	 * @param ctx the parse tree
	 */
	void enterOrdered_list(Tex_grammarParser.Ordered_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#ordered_list}.
	 * @param ctx the parse tree
	 */
	void exitOrdered_list(Tex_grammarParser.Ordered_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#unordered_list}.
	 * @param ctx the parse tree
	 */
	void enterUnordered_list(Tex_grammarParser.Unordered_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#unordered_list}.
	 * @param ctx the parse tree
	 */
	void exitUnordered_list(Tex_grammarParser.Unordered_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#item}.
	 * @param ctx the parse tree
	 */
	void enterItem(Tex_grammarParser.ItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#item}.
	 * @param ctx the parse tree
	 */
	void exitItem(Tex_grammarParser.ItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#listtext}.
	 * @param ctx the parse tree
	 */
	void enterListtext(Tex_grammarParser.ListtextContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#listtext}.
	 * @param ctx the parse tree
	 */
	void exitListtext(Tex_grammarParser.ListtextContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#stat}.
	 * @param ctx the parse tree
	 */
	void enterStat(Tex_grammarParser.StatContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#stat}.
	 * @param ctx the parse tree
	 */
	void exitStat(Tex_grammarParser.StatContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(Tex_grammarParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(Tex_grammarParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#operator}.
	 * @param ctx the parse tree
	 */
	void enterOperator(Tex_grammarParser.OperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#operator}.
	 * @param ctx the parse tree
	 */
	void exitOperator(Tex_grammarParser.OperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#superscript}.
	 * @param ctx the parse tree
	 */
	void enterSuperscript(Tex_grammarParser.SuperscriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#superscript}.
	 * @param ctx the parse tree
	 */
	void exitSuperscript(Tex_grammarParser.SuperscriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#subscript}.
	 * @param ctx the parse tree
	 */
	void enterSubscript(Tex_grammarParser.SubscriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#subscript}.
	 * @param ctx the parse tree
	 */
	void exitSubscript(Tex_grammarParser.SubscriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#frac}.
	 * @param ctx the parse tree
	 */
	void enterFrac(Tex_grammarParser.FracContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#frac}.
	 * @param ctx the parse tree
	 */
	void exitFrac(Tex_grammarParser.FracContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#sqrt}.
	 * @param ctx the parse tree
	 */
	void enterSqrt(Tex_grammarParser.SqrtContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#sqrt}.
	 * @param ctx the parse tree
	 */
	void exitSqrt(Tex_grammarParser.SqrtContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#sum}.
	 * @param ctx the parse tree
	 */
	void enterSum(Tex_grammarParser.SumContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#sum}.
	 * @param ctx the parse tree
	 */
	void exitSum(Tex_grammarParser.SumContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#integralSign}.
	 * @param ctx the parse tree
	 */
	void enterIntegralSign(Tex_grammarParser.IntegralSignContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#integralSign}.
	 * @param ctx the parse tree
	 */
	void exitIntegralSign(Tex_grammarParser.IntegralSignContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#integral}.
	 * @param ctx the parse tree
	 */
	void enterIntegral(Tex_grammarParser.IntegralContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#integral}.
	 * @param ctx the parse tree
	 */
	void exitIntegral(Tex_grammarParser.IntegralContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#integration}.
	 * @param ctx the parse tree
	 */
	void enterIntegration(Tex_grammarParser.IntegrationContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#integration}.
	 * @param ctx the parse tree
	 */
	void exitIntegration(Tex_grammarParser.IntegrationContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#sumsubscript}.
	 * @param ctx the parse tree
	 */
	void enterSumsubscript(Tex_grammarParser.SumsubscriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#sumsubscript}.
	 * @param ctx the parse tree
	 */
	void exitSumsubscript(Tex_grammarParser.SumsubscriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#sumsuperscript}.
	 * @param ctx the parse tree
	 */
	void enterSumsuperscript(Tex_grammarParser.SumsuperscriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#sumsuperscript}.
	 * @param ctx the parse tree
	 */
	void exitSumsuperscript(Tex_grammarParser.SumsuperscriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#mathdata}.
	 * @param ctx the parse tree
	 */
	void enterMathdata(Tex_grammarParser.MathdataContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#mathdata}.
	 * @param ctx the parse tree
	 */
	void exitMathdata(Tex_grammarParser.MathdataContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#fracdata}.
	 * @param ctx the parse tree
	 */
	void enterFracdata(Tex_grammarParser.FracdataContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#fracdata}.
	 * @param ctx the parse tree
	 */
	void exitFracdata(Tex_grammarParser.FracdataContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#fracPart}.
	 * @param ctx the parse tree
	 */
	void enterFracPart(Tex_grammarParser.FracPartContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#fracPart}.
	 * @param ctx the parse tree
	 */
	void exitFracPart(Tex_grammarParser.FracPartContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#inlinemath}.
	 * @param ctx the parse tree
	 */
	void enterInlinemath(Tex_grammarParser.InlinemathContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#inlinemath}.
	 * @param ctx the parse tree
	 */
	void exitInlinemath(Tex_grammarParser.InlinemathContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#displaymath}.
	 * @param ctx the parse tree
	 */
	void enterDisplaymath(Tex_grammarParser.DisplaymathContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#displaymath}.
	 * @param ctx the parse tree
	 */
	void exitDisplaymath(Tex_grammarParser.DisplaymathContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#begin_table}.
	 * @param ctx the parse tree
	 */
	void enterBegin_table(Tex_grammarParser.Begin_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#begin_table}.
	 * @param ctx the parse tree
	 */
	void exitBegin_table(Tex_grammarParser.Begin_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#end_table}.
	 * @param ctx the parse tree
	 */
	void enterEnd_table(Tex_grammarParser.End_tableContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#end_table}.
	 * @param ctx the parse tree
	 */
	void exitEnd_table(Tex_grammarParser.End_tableContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#begin_tabular}.
	 * @param ctx the parse tree
	 */
	void enterBegin_tabular(Tex_grammarParser.Begin_tabularContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#begin_tabular}.
	 * @param ctx the parse tree
	 */
	void exitBegin_tabular(Tex_grammarParser.Begin_tabularContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#end_tabular}.
	 * @param ctx the parse tree
	 */
	void enterEnd_tabular(Tex_grammarParser.End_tabularContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#end_tabular}.
	 * @param ctx the parse tree
	 */
	void exitEnd_tabular(Tex_grammarParser.End_tabularContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#table_alignment}.
	 * @param ctx the parse tree
	 */
	void enterTable_alignment(Tex_grammarParser.Table_alignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#table_alignment}.
	 * @param ctx the parse tree
	 */
	void exitTable_alignment(Tex_grammarParser.Table_alignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#table_row}.
	 * @param ctx the parse tree
	 */
	void enterTable_row(Tex_grammarParser.Table_rowContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#table_row}.
	 * @param ctx the parse tree
	 */
	void exitTable_row(Tex_grammarParser.Table_rowContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#doubleslash}.
	 * @param ctx the parse tree
	 */
	void enterDoubleslash(Tex_grammarParser.DoubleslashContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#doubleslash}.
	 * @param ctx the parse tree
	 */
	void exitDoubleslash(Tex_grammarParser.DoubleslashContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#table_column}.
	 * @param ctx the parse tree
	 */
	void enterTable_column(Tex_grammarParser.Table_columnContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#table_column}.
	 * @param ctx the parse tree
	 */
	void exitTable_column(Tex_grammarParser.Table_columnContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#table}.
	 * @param ctx the parse tree
	 */
	void enterTable(Tex_grammarParser.TableContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#table}.
	 * @param ctx the parse tree
	 */
	void exitTable(Tex_grammarParser.TableContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#latex_newline}.
	 * @param ctx the parse tree
	 */
	void enterLatex_newline(Tex_grammarParser.Latex_newlineContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#latex_newline}.
	 * @param ctx the parse tree
	 */
	void exitLatex_newline(Tex_grammarParser.Latex_newlineContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#boldtext}.
	 * @param ctx the parse tree
	 */
	void enterBoldtext(Tex_grammarParser.BoldtextContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#boldtext}.
	 * @param ctx the parse tree
	 */
	void exitBoldtext(Tex_grammarParser.BoldtextContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#italictext}.
	 * @param ctx the parse tree
	 */
	void enterItalictext(Tex_grammarParser.ItalictextContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#italictext}.
	 * @param ctx the parse tree
	 */
	void exitItalictext(Tex_grammarParser.ItalictextContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#underline}.
	 * @param ctx the parse tree
	 */
	void enterUnderline(Tex_grammarParser.UnderlineContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#underline}.
	 * @param ctx the parse tree
	 */
	void exitUnderline(Tex_grammarParser.UnderlineContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#caption}.
	 * @param ctx the parse tree
	 */
	void enterCaption(Tex_grammarParser.CaptionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#caption}.
	 * @param ctx the parse tree
	 */
	void exitCaption(Tex_grammarParser.CaptionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#label}.
	 * @param ctx the parse tree
	 */
	void enterLabel(Tex_grammarParser.LabelContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#label}.
	 * @param ctx the parse tree
	 */
	void exitLabel(Tex_grammarParser.LabelContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#ref}.
	 * @param ctx the parse tree
	 */
	void enterRef(Tex_grammarParser.RefContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#ref}.
	 * @param ctx the parse tree
	 */
	void exitRef(Tex_grammarParser.RefContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#text}.
	 * @param ctx the parse tree
	 */
	void enterText(Tex_grammarParser.TextContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#text}.
	 * @param ctx the parse tree
	 */
	void exitText(Tex_grammarParser.TextContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#fulltext}.
	 * @param ctx the parse tree
	 */
	void enterFulltext(Tex_grammarParser.FulltextContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#fulltext}.
	 * @param ctx the parse tree
	 */
	void exitFulltext(Tex_grammarParser.FulltextContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#word}.
	 * @param ctx the parse tree
	 */
	void enterWord(Tex_grammarParser.WordContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#word}.
	 * @param ctx the parse tree
	 */
	void exitWord(Tex_grammarParser.WordContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#letter}.
	 * @param ctx the parse tree
	 */
	void enterLetter(Tex_grammarParser.LetterContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#letter}.
	 * @param ctx the parse tree
	 */
	void exitLetter(Tex_grammarParser.LetterContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#integer}.
	 * @param ctx the parse tree
	 */
	void enterInteger(Tex_grammarParser.IntegerContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#integer}.
	 * @param ctx the parse tree
	 */
	void exitInteger(Tex_grammarParser.IntegerContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#sentence}.
	 * @param ctx the parse tree
	 */
	void enterSentence(Tex_grammarParser.SentenceContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#sentence}.
	 * @param ctx the parse tree
	 */
	void exitSentence(Tex_grammarParser.SentenceContext ctx);
	/**
	 * Enter a parse tree produced by {@link Tex_grammarParser#line}.
	 * @param ctx the parse tree
	 */
	void enterLine(Tex_grammarParser.LineContext ctx);
	/**
	 * Exit a parse tree produced by {@link Tex_grammarParser#line}.
	 * @param ctx the parse tree
	 */
	void exitLine(Tex_grammarParser.LineContext ctx);
}